<?php
/**
 * ARCHIVO: api/explorer.php
 * Se encarga de navegar, crear carpetas, mover y borrar (ahora de forma recursiva y segura para +2GB).
 */
header('Content-Type: application/json');

// Función recursiva para borrar carpetas y archivos gigantes en FTP
function borrar_directorio_recursivo($conn_id, $dir) {
    $archivos = @ftp_nlist($conn_id, $dir);
    if (is_array($archivos)) {
        foreach ($archivos as $archivo) {
            $nombre_base = basename($archivo);
            if ($nombre_base == '.' || $nombre_base == '..') continue;
            
            $ruta_completa = $dir . '/' . $nombre_base;
            
            $es_carpeta = false;
            $directorio_actual = @ftp_pwd($conn_id);
            
            if (@ftp_chdir($conn_id, $ruta_completa)) {
                $es_carpeta = true;
                @ftp_chdir($conn_id, $directorio_actual);
            }
            
            if ($es_carpeta) {
                borrar_directorio_recursivo($conn_id, $ruta_completa);
            } else {
                @ftp_delete($conn_id, $ruta_completa);
            }
        }
    }
    return @ftp_rmdir($conn_id, $dir);
}

if (isset($_POST['action']) && in_array($_POST['action'], ['list_dir', 'delete_item', 'mkdir', 'rename'])) {
    $host_ip = $_POST['host_ip'];
    // Timeout subido a 15s
    $conn_id = @ftp_connect($host_ip, 2121, 15);
    
    if ($conn_id && @ftp_login($conn_id, "anonymous", "")) {
        ftp_pasv($conn_id, true); 
        
        if ($_POST['action'] == 'list_dir') {
            $path = $_POST['path'];
            $raw = @ftp_rawlist($conn_id, $path);
            $list = [];
            if (is_array($raw)) {
                foreach ($raw as $line) {
                    $parts = preg_split('/\s+/', $line, 9);
                    if (count($parts) < 9) continue;
                    $name = $parts[8];
                    if ($name == '.' || $name == '..') continue;
                    $is_dir = ($parts[0][0] === 'd');
                    $size = $parts[4];
                    $list[] = ['name' => $name, 'is_dir' => $is_dir, 'size' => $size];
                }
                usort($list, function($a, $b) {
                    if ($a['is_dir'] == $b['is_dir']) return strcasecmp($a['name'], $b['name']);
                    return $a['is_dir'] ? -1 : 1;
                });
            }
            echo json_encode(['status' => 'success', 'data' => $list, 'path' => $path]);
        }
        elseif ($_POST['action'] == 'delete_item') {
            $path = $_POST['path']; 
            $is_dir = $_POST['is_dir'] === 'true';
            
            if ($is_dir) {
                $res = borrar_directorio_recursivo($conn_id, $path);
            } else {
                $res = @ftp_delete($conn_id, $path);
            }
            
            if ($res) echo json_encode(['status' => 'success']);
            else echo json_encode(['status' => 'error', 'message' => 'No se pudo borrar. Verifica permisos en la PS4.']);
        }
        elseif ($_POST['action'] == 'mkdir') {
            $path = $_POST['path'];
            if (@ftp_mkdir($conn_id, $path)) echo json_encode(['status' => 'success']);
            else echo json_encode(['status' => 'error', 'message' => 'No se pudo crear la carpeta.']);
        }
        elseif ($_POST['action'] == 'rename') {
            $old = $_POST['old_path']; $new = $_POST['new_path'];
            if (@ftp_rename($conn_id, $old, $new)) echo json_encode(['status' => 'success']);
            else echo json_encode(['status' => 'error', 'message' => 'Error al mover o renombrar.']);
        }
    } else { echo json_encode(['status' => 'error', 'message' => 'No conectado a la PS4.']); }
    @ftp_close($conn_id);
    exit;
}
?>