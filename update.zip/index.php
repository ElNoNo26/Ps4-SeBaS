<?php
/**
 * ====================================================================
 * GOLDHEN MANAGER V1.0 (PS5 UI FINAL - SAQUEO TOTAL INTELIGENTE)
 * DEVELOPED BY SEBAS
 * ====================================================================
 */

// 1. AUTO-CREACIÓN PWA E ICONO
$manifest_content = '{
  "name": "GoldHen Manager", "short_name": "GoldHen Manager",
  "start_url": "./index.php", "display": "standalone", "background_color": "#0b0c10",
  "theme_color": "#0b0c10", "icons": [{"src": "icon-512.png?v=7", "sizes": "512x512", "type": "image/png", "purpose": "any"}]
}';
if (!file_exists('manifest.json')) { @file_put_contents('manifest.json', $manifest_content); }

$sw_content = "self.addEventListener('install', (e) => self.skipWaiting());\nself.addEventListener('activate', (e) => self.clients.claim());\nself.addEventListener('fetch', (e) => e.respondWith(fetch(e.request)));";
if (!file_exists('sw.js')) { @file_put_contents('sw.js', $sw_content); }

if (!file_exists('icon-512.png')) {
    $icon_url = 'https://raw.githubusercontent.com/ElNoNo26/Ps4-SeBaS/main/icon-512.png';
    if (function_exists('curl_init')) {
        $ch = curl_init($icon_url); $fp = fopen('icon-512.png', 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp); curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch); curl_close($ch); fclose($fp);
    } elseif (ini_get('allow_url_fopen')) {
        @file_put_contents('icon-512.png', file_get_contents($icon_url));
    }
}

// 2. AUTO-DESCUBRIMIENTO DE ICONOS Y PAYLOADS
$iconos_locales = [];
if (!file_exists('iconos')) { @mkdir('iconos', 0777, true); }
if (file_exists('iconos') && is_dir('iconos')) {
    $archivos = glob('iconos/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
    if (is_array($archivos)) {
        foreach($archivos as $archivo) { $iconos_locales[] = ['nombre' => basename($archivo), 'url' => $archivo]; }
    }
}

$backups_locales = [];
if (!file_exists('backup_icons')) { @mkdir('backup_icons', 0777, true); }
if (file_exists('backup_icons') && is_dir('backup_icons')) {
    $archivos = glob('backup_icons/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
    if (is_array($archivos)) {
        foreach($archivos as $archivo) { $backups_locales[] = ['nombre' => basename($archivo), 'url' => $archivo]; }
    }
}

$payloads_locales = [];
if (!file_exists('payloads')) { @mkdir('payloads', 0777, true); }
if (file_exists('payloads') && is_dir('payloads')) {
    $archivos_bin = glob('payloads/*.bin');
    if (is_array($archivos_bin)) {
        foreach($archivos_bin as $archivo) { 
            $payloads_locales[] = ['nombre' => basename($archivo), 'url' => $archivo]; 
        }
    }
}

// 3. IP DEL SERVIDOR
$ip_servidor = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : '192.168.0.1';
if (strpos($ip_servidor, '127.') === 0 || $ip_servidor == '::1') $ip_servidor = getHostByName(getHostName());
$subred_actual = (strpos($ip_servidor, '192.168.') === 0) ? substr($ip_servidor, 0, strrpos($ip_servidor, '.') + 1) : '192.168.0.';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>GoldHen Manager</title>
    
    <link rel="manifest" href="manifest.json?v=7">
    <meta name="theme-color" content="#0b0c10">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="apple-touch-icon" href="icon-512.png?v=7">

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    
    <style>
        :root { --ps5-bg: #0b0c10; --glass-bg: rgba(255, 255, 255, 0.03); --glass-border: rgba(255, 255, 255, 0.08); --dock-active: rgba(255, 255, 255, 0.15); }
        body { font-family: 'Outfit', sans-serif; background-color: var(--ps5-bg); color: #ffffff; overflow-x: hidden; -webkit-user-select: none; user-select: none; touch-action: pan-y; margin: 0; min-height: 100vh; padding-bottom: calc(180px + env(safe-area-inset-bottom)); }

        /* PANTALLA DE INTRO (Warp Speed) */
        #intro-screen { position: fixed; inset: 0; z-index: 200; display: flex; align-items: center; justify-content: center; background: #000; transition: opacity 1.5s ease; }
        #stardust { position: absolute; inset: 0; width: 100%; height: 100%; }
        #logo-wrapper { position: relative; z-index: 10; opacity: 0; transform: scale(0.9); filter: blur(10px); transition: all 3s ease; }
        .ps-logo-intro { font-size: 6rem; color: white; filter: drop-shadow(0 0 15px rgba(255,255,255,0.4)); }
        
        /* INTERFAZ PRINCIPAL */
        #app-ui { opacity: 0; transition: opacity 1.5s ease; }
        
        .ambient-bg { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: -1; overflow: hidden; background: radial-gradient(circle at 50% 50%, #111827 0%, var(--ps5-bg) 100%); transform: scale(1.2); transition: transform 2.5s cubic-bezier(0.16, 1, 0.3, 1); }
        .orb { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.4; animation: float-orb 20s infinite alternate ease-in-out; }
        .orb-1 { width: 300px; height: 300px; background: #3730a3; top: -10%; left: -10%; }
        .orb-2 { width: 400px; height: 400px; background: #1e3a8a; bottom: -20%; right: -10%; animation-delay: -5s; }
        .orb-3 { width: 250px; height: 250px; background: #0f172a; top: 40%; left: 40%; animation-delay: -10s; }
        @keyframes float-orb { 0% { transform: translate(0, 0) scale(1); } 50% { transform: translate(30px, 50px) scale(1.2); } 100% { transform: translate(-20px, 20px) scale(0.9); } }

        .glass-panel { background: var(--glass-bg); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid var(--glass-border); box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); }
        .modal-glass { background: rgba(5, 5, 8, 0.85); backdrop-filter: blur(25px); -webkit-backdrop-filter: blur(25px); }

        .btn-ps5 { background: var(--glass-bg); border: 1px solid var(--glass-border); backdrop-filter: blur(10px); transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); cursor: pointer; }
        .btn-ps5:active { transform: scale(0.96); background: rgba(255, 255, 255, 0.1); }
        .btn-ps5-primary { background: rgba(255, 255, 255, 0.9); color: black; border: none; box-shadow: 0 0 20px rgba(255,255,255,0.2); transition: all 0.2s; cursor: pointer;}
        .btn-ps5-primary:active { transform: scale(0.96); background: white; box-shadow: 0 0 30px rgba(255,255,255,0.5); }
        .btn-ps5-danger { background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.5); color: #fca5a5; transition: all 0.2s;}
        .btn-ps5-danger:active { background: rgba(239, 68, 68, 0.4); transform: scale(0.96); }

        input[type=range] { -webkit-appearance: none; background: transparent; }
        input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; height: 16px; width: 16px; border-radius: 50%; background: #ffffff; cursor: pointer; margin-top: -6px; box-shadow: 0 0 10px rgba(255,255,255,0.8); transition: transform 0.1s; }
        input[type=range]::-webkit-slider-thumb:active { transform: scale(1.3); }
        input[type=range]::-webkit-slider-runnable-track { width: 100%; height: 4px; cursor: pointer; background: rgba(255,255,255,0.2); border-radius: 2px; }

        .dock-nav { position: fixed; bottom: calc(20px + env(safe-area-inset-bottom)); left: 50%; transform: translateX(-50%); z-index: 40; display: flex; gap: 5px; padding: 8px; border-radius: 9999px; background: rgba(10, 10, 15, 0.6); backdrop-filter: blur(25px); -webkit-backdrop-filter: blur(25px); border: 1px solid rgba(255,255,255,0.05); box-shadow: 0 10px 30px rgba(0,0,0,0.8); }
        .dock-item { width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: rgba(255,255,255,0.4); font-size: 1.2rem; transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); cursor: pointer;}
        .dock-item.active { color: white; background: rgba(255,255,255,0.1); transform: translateY(-8px) scale(1.1); box-shadow: 0 10px 20px rgba(0,0,0,0.5), inset 0 0 0 1px rgba(255,255,255,0.2); }
        .dock-item.active::after { content: ''; position: absolute; bottom: -8px; left: 50%; transform: translateX(-50%); width: 6px; height: 6px; border-radius: 50%; background: white; box-shadow: 0 0 10px white; }

        .floating-btn-global { position: fixed; bottom: calc(100px + env(safe-area-inset-bottom)); left: 50%; transform: translateX(-50%); width: 100%; max-width: 32rem; padding: 0 1.25rem; z-index: 35; transition: opacity 0.4s, transform 0.4s cubic-bezier(0.16, 1, 0.3, 1); }
        .floating-hidden { opacity: 0; pointer-events: none; transform: translate(-50%, 30px) scale(0.95); }

        .tab-content { display: none; opacity: 0; transform: translateY(20px) scale(0.98); transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1); }
        .tab-content.active { display: block; opacity: 1; transform: translateY(0) scale(1); }
        
        .custom-scrollbar::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background-color: rgba(255,255,255,0.2); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-track { background-color: transparent; }
        
        .folder-btn.active { background: rgba(255,255,255,0.2); border-color: rgba(255,255,255,0.5); color: white; }
        .payload-item.selected { background: rgba(255,255,255,0.15); border-color: rgba(255,255,255,0.4); }
        .gallery-item { position: relative; cursor: pointer; border-radius: 12px; overflow: hidden; border: 2px solid transparent; transition: all 0.2s; background-color: #111; width: 100%; padding-bottom: 100%; }
        .gallery-item.selected { border-color: white; box-shadow: 0 0 15px rgba(255,255,255, 0.4); transform: scale(0.95); }
        .gallery-item img { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; display: block; pointer-events: none;}
        
        .toggle-checkbox { display: none; }
        .toggle-label { display: inline-block; position: relative; width: 50px; height: 26px; background-color: rgba(255,255,255,0.1); border-radius: 9999px; transition: background-color 0.3s ease; cursor: pointer; border: 1px solid rgba(255,255,255,0.2);}
        .toggle-label::after { content: ''; position: absolute; top: 2px; left: 3px; width: 20px; height: 20px; background-color: white; border-radius: 50%; transition: transform 0.3s cubic-bezier(0.4, 0.0, 0.2, 1); box-shadow: 0 2px 4px rgba(0,0,0,0.3); }
        .toggle-checkbox:checked + .toggle-label { background-color: white; border-color: white;}
        .toggle-checkbox:checked + .toggle-label::after { transform: translateX(22px); background-color: black;}

        .bottom-sheet { position: fixed; bottom: 0; left: 50%; transform: translateX(-50%) translateY(100%); width: 100%; max-width: 32rem; background: #111827; border-top-left-radius: 24px; border-top-right-radius: 24px; z-index: 60; transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1); border-top: 1px solid rgba(255,255,255,0.1); padding-bottom: env(safe-area-inset-bottom); }
        .bottom-sheet.open { transform: translateX(-50%) translateY(0); }
        .overlay-sheet { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 55; opacity: 0; pointer-events: none; transition: opacity 0.3s; backdrop-filter: blur(5px); }
        .overlay-sheet.open { opacity: 1; pointer-events: auto; }
    </style>
</head>
<body>

    <div id="intro-screen">
        <canvas id="stardust"></canvas>
        <div id="logo-wrapper">
            <i class="fa-brands fa-playstation ps-logo-intro"></i>
        </div>
    </div>

    <div id="app-ui">
        <div class="ambient-bg" id="ambient-bg">
            <div class="orb orb-1"></div><div class="orb orb-2"></div><div class="orb orb-3"></div>
        </div>

        <header class="w-full max-w-md mx-auto pt-8 px-5 flex justify-between items-center relative z-10 mb-4">
            <div id="badge-detectada" class="hidden flex items-center gap-3 glass-panel px-4 py-2 rounded-full border-green-500/30">
                <div id="badge-dot" class="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-[0_0_8px_#4ade80]"></div>
                <span id="badge-text" class="text-[9px] font-bold tracking-widest text-green-100 uppercase" data-i18n="ps4_detected">PS4 DETECTADA</span>
            </div>
            <div id="badge-desconectada" class="flex items-center gap-3 glass-panel px-4 py-2 rounded-full border-red-500/30">
                <div class="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]"></div>
                <span class="text-[9px] font-bold tracking-widest text-red-100 uppercase" data-i18n="ps4_disconnected">DESCONECTADA</span>
            </div>
            
            <div class="flex items-center gap-2.5 cursor-pointer group" onclick="cambiarNombreUsuario()" title="Toca para cambiar nombre">
                <div id="profile-avatar" class="w-8 h-8 rounded-full bg-[#549E43] flex items-center justify-center border border-[#386C2B] shadow-sm bg-cover bg-center transition-all duration-500 overflow-hidden relative">
                    <span id="profile-initial" class="text-white font-bold text-[15px] relative z-10">S</span>
                    <div class="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center z-20"><i class="fa-solid fa-pen text-[10px] text-white"></i></div>
                </div>
                <span id="profile-name" class="text-[11px] font-black tracking-[0.15em] text-[#A1A1AA] transition-colors duration-500">BY SEBAS</span>
            </div>
        </header>

        <div class="w-full max-w-md mx-auto px-5 relative z-10 mb-4">
            <div class="glass-panel rounded-2xl p-2 flex gap-2 items-center shadow-lg">
                <div class="flex-1 flex items-center px-3 bg-black/40 rounded-xl border border-white/5 focus-within:border-white/30 transition-colors relative">
                    <i class="fa-solid fa-network-wired text-white/40 text-xs mr-3"></i>
                    <input type="text" id="host-ip" placeholder="IP PS4 (192.168.x.x)" class="bg-transparent w-full text-sm font-mono outline-none text-white py-3 placeholder-white/20" autocomplete="off">
                    <i class="fa-solid fa-xmark text-white/40 hover:text-white cursor-pointer px-3 py-2 relative z-20" onclick="clearIP()"></i>
                </div>
                <button id="btn-scan" onclick="toggleRealScan()" class="w-12 h-12 rounded-xl bg-blue-600 hover:bg-blue-500 transition-all flex items-center justify-center text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] active:scale-95"><i class="fa-solid fa-satellite-dish" id="scan-icon"></i></button>
                <button onclick="connectManualIP()" class="w-12 h-12 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 transition-all flex items-center justify-center text-white active:scale-95"><i class="fa-solid fa-plug" id="connect-icon"></i></button>
            </div>
            <p id="global-status" class="text-[10px] text-center mt-2 font-mono text-blue-400 hidden">
                <i class="fa-solid fa-satellite-dish fa-fade mr-1 text-white"></i> <span id="scan-text" data-i18n="searching">BUSCANDO...</span>
            </p>
        </div>

        <div id="install-pwa-container" class="hidden w-full max-w-md mx-auto px-5 relative z-10 mb-6 transition-all duration-300">
            <div class="bg-blue-600/20 border border-blue-500/30 rounded-2xl p-4 relative overflow-hidden flex items-center justify-between shadow-lg">
                <div class="absolute top-0 right-0 w-20 h-20 bg-blue-400/20 blur-[30px] rounded-full pointer-events-none"></div>
                <div class="flex items-center gap-3 relative z-10">
                    <div class="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center shrink-0 border border-blue-400/30">
                        <i class="fa-solid fa-mobile-screen-button text-blue-400 text-lg"></i>
                    </div>
                    <div>
                        <span class="text-xs font-bold text-white block" data-i18n="install_app">Instalar App</span>
                        <span class="text-[9px] text-white/60" data-i18n="install_desc">Añadir a pantalla de inicio</span>
                    </div>
                </div>
                <div class="flex items-center gap-2 relative z-10">
                    <button onclick="installPWA()" class="bg-white text-black font-bold text-[9px] tracking-widest px-4 py-2.5 rounded-lg transition-transform active:scale-95 shadow-[0_0_15px_rgba(255,255,255,0.3)]">INSTALAR</button>
                    <button onclick="dismissPWA()" class="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-white/50 hover:text-white flex items-center justify-center transition-colors"><i class="fa-solid fa-xmark"></i></button>
                </div>
            </div>
        </div>

        <main class="w-full max-w-md mx-auto px-5 relative z-10">
            
            <div id="tab-ftp" class="tab-content active">
                <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_transfer">Transferir</h1>
                <p class="text-xs text-white/50 mb-6 font-light tracking-wide" data-i18n="desc_transfer">Envía juegos o aplicaciones a tu consola.</p>

                <form id="ftp-form" onsubmit="enviarArchivoChunks(event)">
                    <div class="glass-panel rounded-[2rem] p-6 mb-6">
                        <h2 class="text-xs font-bold tracking-widest text-white/70 mb-4" data-i18n="dest_routes"><i class="fa-solid fa-folder-open mr-2"></i>RUTAS DE DESTINO</h2>
                        <div class="grid grid-cols-2 gap-3 mb-6" id="paths-grid">
                            <button type="button" class="folder-btn active btn-ps5 rounded-xl py-3 text-xs font-bold text-white/60 border border-white/10" onclick="selectPath(this, '/data/')">/data/</button>
                            <button type="button" class="folder-btn btn-ps5 rounded-xl py-3 text-xs font-bold text-white/60 border border-white/10" onclick="selectPath(this, '/data/pkg/')">/data/pkg/</button>
                            <button type="button" class="folder-btn btn-ps5 rounded-xl py-3 text-[11px] font-bold text-white/60 border border-white/10" onclick="selectPath(this, '/mnt/usb0/')">/mnt/usb0/</button>
                            <button type="button" id="btn-otra" class="folder-btn btn-ps5 rounded-xl py-3 text-xs font-bold text-white/60 border border-dashed border-white/20 flex items-center justify-center" onclick="showAddPathUI()"><i class="fa-solid fa-plus"></i></button>
                        </div>
                        <input type="hidden" id="selected-path-input" value="/data/">
                        
                        <div id="add-path-ui" class="hidden mb-6 flex gap-2">
                            <input type="text" id="new-path-input" placeholder="/ruta/" class="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 text-sm font-mono text-white outline-none">
                            <button type="button" onclick="saveNewPath()" class="bg-white text-black px-4 rounded-xl font-bold"><i class="fa-solid fa-check"></i></button>
                            <button type="button" onclick="hideAddPathUI()" class="bg-white/10 text-white px-4 rounded-xl border border-white/10"><i class="fa-solid fa-xmark"></i></button>
                        </div>

                        <h2 class="text-xs font-bold tracking-widest text-white/70 mb-4" data-i18n="files_pkg"><i class="fa-solid fa-file-circle-plus mr-2"></i>ARCHIVOS (PKG/BIN)</h2>
                        <div onclick="document.getElementById('file-upload').click()" class="w-full aspect-video border border-dashed border-white/20 rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all hover:bg-white/5 group relative overflow-hidden bg-black/20">
                            <div id="upload-icon-container" class="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-white mb-3 group-hover:scale-110 transition-transform duration-500">
                                <i class="fa-solid fa-cloud-arrow-up text-2xl"></i>
                            </div>
                            <span id="file-name-display" class="text-[10px] font-bold tracking-widest text-white/50 group-hover:text-white transition-colors text-center px-4" data-i18n="touch_select">TOCA PARA SELECCIONAR</span>
                            <input type="file" id="file-upload" class="hidden" multiple onchange="updateFileName(this)">
                        </div>
                    </div>
                    <button type="submit" id="ftp-form-submit" class="hidden"></button>
                </form>
            </div>

            <div id="tab-icons" class="tab-content">
                <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_mod">Modding</h1>
                <p class="text-xs text-white/50 mb-6 font-light tracking-wide" data-i18n="desc_mod">Personaliza el arte de tu biblioteca.</p>

                <form id="icon-form" onsubmit="enviarIcono(event)">
                    <div class="glass-panel rounded-[2rem] p-6 mb-6">
                        
                        <div class="flex gap-2 mb-6 items-end">
                            <div class="flex-1 relative">
                                <label class="text-[10px] font-bold tracking-widest text-white/70 block mb-3">TITLE ID (EJ: CUSA00000)</label>
                                <input type="text" id="icon-cusa" placeholder="CUSA12345" oninput="this.value = this.value.toUpperCase();" class="w-full bg-black/40 border border-white/10 focus:border-white/30 rounded-2xl px-5 py-4 font-mono text-center text-lg outline-none text-white transition-colors uppercase">
                            </div>
                            <button type="button" onclick="respaldarOriginal()" class="h-[58px] px-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold flex flex-col items-center justify-center transition-all shadow-lg active:scale-95">
                                <i class="fa-solid fa-download mb-1 text-lg"></i>
                                <span class="text-[8px] tracking-widest">ESTE</span>
                            </button>
                            <button type="button" onclick="respaldarTodos()" class="h-[58px] px-3 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl font-bold flex flex-col items-center justify-center transition-all shadow-[0_0_15px_rgba(147,51,234,0.4)] active:scale-95">
                                <i class="fa-solid fa-layer-group mb-1 text-lg"></i>
                                <span class="text-[8px] tracking-widest">TODOS</span>
                            </button>
                        </div>

                        <div class="flex gap-1.5 p-1 bg-black/40 rounded-[1.2rem] mb-6 border border-white/5 overflow-x-auto custom-scrollbar">
                            <button type="button" id="btn-src-gallery" class="flex-1 py-3 px-3 text-[9px] font-bold tracking-widest rounded-xl bg-white text-black shadow-lg whitespace-nowrap" onclick="switchIconSource('gallery')" data-i18n="gallery">GALERÍA</button>
                            <button type="button" id="btn-src-backup" class="flex-1 py-3 px-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors whitespace-nowrap" onclick="switchIconSource('backup')">BACKUPS</button>
                            <button type="button" id="btn-src-import" class="flex-1 py-3 px-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors whitespace-nowrap" onclick="switchIconSource('import')" data-i18n="import">IMPORTAR</button>
                            <button type="button" id="btn-src-local" class="flex-1 py-3 px-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors whitespace-nowrap" onclick="switchIconSource('local')" data-i18n="local">LOCAL</button>
                        </div>
                        
                        <div id="box-src-gallery" class="animate-fade-in"><div id="gallery-container"></div></div>
                        <div id="box-src-backup" class="hidden animate-fade-in"><div id="backup-container"></div></div>

                        <div id="box-src-import" class="hidden animate-fade-in">
                            <div class="bg-black/20 border border-white/5 rounded-[1.5rem] p-5 text-center h-[250px] flex flex-col justify-center">
                                <i class="fa-solid fa-cloud-arrow-down text-4xl text-white/30 mb-3"></i>
                                <p class="text-[10px] text-white/50 mb-4 px-2" data-i18n="import_desc">Pega un link directo de imagen o carpeta de GitHub para descargarla a tu galería.</p>
                                <input type="url" id="import-url" placeholder="https://..." class="w-full bg-black/60 rounded-xl px-4 py-3 border border-white/10 font-mono text-xs text-white outline-none mb-4">
                                <button type="button" id="btn-cargar-url" onclick="importarURL()" class="w-full bg-white/10 hover:bg-white/20 border border-white/10 text-white rounded-xl py-3 font-bold text-[10px] tracking-widest transition-colors" data-i18n="btn_import">INICIAR IMPORTACIÓN</button>
                            </div>
                        </div>

                        <div id="box-src-local" class="hidden animate-fade-in">
                            <div onclick="document.getElementById('icon-file').click()" class="w-full h-[250px] bg-black/20 rounded-[1.5rem] border border-dashed border-white/20 hover:border-white/50 flex flex-col items-center justify-center cursor-pointer overflow-hidden relative transition-colors">
                                <i id="icon-file-placeholder" class="fa-solid fa-image text-4xl text-white/20 mb-3 relative z-10"></i>
                                <span id="icon-file-name" class="text-[10px] font-bold tracking-widest text-white/50 relative z-10 text-center px-4" data-i18n="touch_image">TOCA PARA BUSCAR IMAGEN</span>
                                <img id="preview-img-local" src="" class="hidden absolute inset-0 w-full h-full object-contain z-20 bg-black/90">
                                <input type="file" id="icon-file" accept="image/png, image/jpeg" class="hidden" onchange="previewLocal(this)">
                            </div>
                        </div>
                    </div>
                    <button type="submit" id="icon-form-submit" class="hidden"></button>
                </form>
            </div>

            <div id="tab-explorer" class="tab-content">
                <div class="flex justify-between items-end mb-6">
                    <div>
                        <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_exp">Explorador</h1>
                        <p class="text-xs text-white/50 font-light tracking-wide" data-i18n="desc_exp">Gestor de archivos interno.</p>
                    </div>
                    <div class="flex gap-1.5 flex-wrap justify-end">
                        <button onclick="addCurrentPathToShortcuts()" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white hover:bg-yellow-500/20 hover:text-yellow-400 hover:border-yellow-500/30 transition-colors"><i class="fa-solid fa-star"></i></button>
                        <button onclick="promptCreateFolder()" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"><i class="fa-solid fa-folder-plus"></i></button>
                        <button id="btn-select-mode" onclick="toggleSelectMode()" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white hover:bg-blue-500/20 hover:text-blue-400 transition-colors"><i class="fa-solid fa-list-check"></i></button>
                        <button onclick="if(currentExplorerPath) loadExplorerPath(currentExplorerPath)" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"><i class="fa-solid fa-rotate-right"></i></button>
                        <button onclick="loadExplorerPath('/')" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"><i class="fa-solid fa-home"></i></button>
                    </div>
                </div>

                <div id="clipboard-panel" class="hidden mb-4 glass-panel rounded-xl p-3 flex justify-between items-center border-blue-500/30">
                    <div class="flex items-center gap-3 overflow-hidden pr-2">
                        <i class="fa-solid fa-scissors text-blue-400 text-sm"></i>
                        <span id="clipboard-text" class="text-[11px] text-white font-mono truncate">...</span>
                    </div>
                    <div class="flex gap-2 shrink-0">
                        <button onclick="cancelPaste()" class="text-white/50 hover:text-red-400 text-sm p-1"><i class="fa-solid fa-xmark"></i></button>
                        <button onclick="executePaste()" class="bg-white text-black px-4 py-1.5 rounded-lg text-[10px] font-bold"><i class="fa-solid fa-paste mr-1"></i> <span data-i18n="btn_paste">PEGAR</span></button>
                    </div>
                </div>

                <div id="multi-action-panel" class="hidden mb-4 glass-panel rounded-xl p-3 flex justify-between items-center border-red-500/30 animate-fade-in">
                    <div class="flex items-center gap-2">
                        <div class="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center"><i class="fa-solid fa-check-double text-[10px] text-red-400"></i></div>
                        <span id="multi-select-count" class="text-[11px] text-white font-bold tracking-wide">0 seleccionados</span>
                    </div>
                    <button onclick="deleteSelectedItems()" class="bg-red-500 text-white px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest shadow-lg shadow-red-500/20 active:scale-95 transition-all"><i class="fa-solid fa-trash mr-1"></i> <span data-i18n="btn_delete">ELIMINAR</span></button>
                </div>

                <div class="glass-panel rounded-[2rem] overflow-hidden flex flex-col h-[55vh]">
                    <div class="bg-black/40 px-5 py-4 border-b border-white/10 flex items-center gap-3 overflow-x-auto custom-scrollbar shrink-0">
                        <i class="fa-solid fa-hard-drive text-white/50"></i>
                        <span id="explorer-path-text" class="text-xs font-mono text-white/80 whitespace-nowrap">/</span>
                    </div>
                    <div id="explorer-shortcuts" class="hidden bg-black/60 px-4 py-2 border-b border-white/5 flex items-center gap-2 overflow-x-auto custom-scrollbar shrink-0"></div>

                    <div id="explorer-list" class="flex-1 p-2 flex flex-col gap-1 overflow-y-auto custom-scrollbar bg-black/20">
                        <div class="text-center text-white/30 text-xs py-20"><i class="fa-solid fa-folder-tree text-4xl mb-4 block opacity-50"></i><span data-i18n="config_ip">Configura tu IP para explorar.</span></div>
                    </div>
                </div>
            </div>

            <div id="tab-payloads" class="tab-content">
                <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_pay">Payloads</h1>
                <p class="text-xs text-white/50 mb-6 font-light tracking-wide" data-i18n="desc_pay">Inyección de código BinLoader.</p>
                
                <form id="payload-form" onsubmit="enviarPayload(event)">
                    <div class="glass-panel rounded-[2rem] p-6 mb-6">
                        <div class="flex items-center justify-between bg-black/40 border border-white/10 rounded-2xl px-5 py-4 mb-6">
                            <span class="text-[10px] font-bold tracking-widest text-white/70" data-i18n="local_port">PUERTO LOCAL</span>
                            <input type="number" id="payload-port" value="9020" class="bg-transparent text-right font-mono text-white text-lg outline-none w-20 border-b border-dashed border-white/20 focus:border-white" required>
                        </div>

                        <div class="flex gap-2 p-1 bg-black/40 rounded-[1.2rem] mb-6 border border-white/5">
                            <button type="button" id="btn-pay-gallery" class="flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl bg-white text-black shadow-lg" onclick="switchPayloadSource('gallery')" data-i18n="gallery">GALERÍA</button>
                            <button type="button" id="btn-pay-local" class="flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors" onclick="switchPayloadSource('local')" data-i18n="device">DISPOSITIVO</button>
                        </div>

                        <div id="box-pay-gallery" class="animate-fade-in relative">
                            <div class="absolute bottom-0 w-full h-8 bg-gradient-to-t from-[var(--ps5-bg)] to-transparent z-10 pointer-events-none rounded-b-[1.5rem]"></div>
                            <div id="payload-gallery-container"></div>
                        </div>

                        <div id="box-pay-local" class="hidden animate-fade-in">
                            <div onclick="document.getElementById('payload-file').click()" class="w-full h-[250px] bg-black/20 rounded-[1.5rem] border border-dashed border-white/20 hover:border-white/50 flex flex-col items-center justify-center cursor-pointer transition-colors relative">
                                <div id="payload-icon-container" class="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-white mb-3">
                                    <i class="fa-solid fa-file-code text-2xl"></i>
                                </div>
                                <span id="payload-name-display" class="text-[10px] font-bold tracking-widest text-white/50 text-center px-6" data-i18n="touch_bin">TOCA PARA BUSCAR .BIN</span>
                                <input type="file" id="payload-file" accept=".bin" class="hidden" onchange="updatePayloadName(this)">
                            </div>
                        </div>
                    </div>
                    <button type="submit" id="payload-form-submit" class="hidden"></button>
                </form>
            </div>

            <div id="tab-settings" class="tab-content">
                <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_set">Ajustes</h1>
                <p class="text-xs text-white/50 mb-6 font-light tracking-wide" data-i18n="desc_set">Configuración del sistema.</p>

                <div class="glass-panel rounded-[2rem] p-6 mb-6">
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex-1 pr-4">
                            <span class="text-sm font-bold text-white block mb-1" data-i18n="set_lang"><i class="fa-solid fa-language text-white/50 mr-2"></i>Idioma / Language</span>
                            <p class="text-[10px] text-white/40 leading-relaxed pl-6" data-i18n="set_lang_desc">Cambia el idioma de la interfaz.</p>
                        </div>
                        <div class="flex bg-black/40 rounded-xl p-1 border border-white/10 shrink-0">
                            <button onclick="setLanguage('es')" id="btn-lang-es" class="px-4 py-2 text-[10px] font-bold rounded-lg bg-white text-black shadow-lg transition-all">ES</button>
                            <button onclick="setLanguage('en')" id="btn-lang-en" class="px-4 py-2 text-[10px] font-bold rounded-lg text-white/50 hover:text-white transition-all">EN</button>
                        </div>
                    </div>
                    <div class="w-full h-px bg-white/10 mb-6 ml-6"></div>
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex-1 pr-4">
                            <span class="text-sm font-bold text-white block mb-1" data-i18n="set_wake"><i class="fa-solid fa-lock text-white/50 mr-2"></i>Pantalla Activa</span>
                            <p class="text-[10px] text-white/40 leading-relaxed pl-6" data-i18n="set_wake_desc">Evita que el dispositivo se apague.</p>
                        </div>
                        <input type="checkbox" id="toggle_wakelock" class="toggle-checkbox" checked/>
                        <label for="toggle_wakelock" class="toggle-label"></label>
                    </div>
                    <div class="w-full h-px bg-white/10 mb-6 ml-6"></div>
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex-1 pr-4">
                            <span class="text-sm font-bold text-white block mb-1" data-i18n="set_sound"><i class="fa-solid fa-bell text-white/50 mr-2"></i>Sonidos UI</span>
                            <p class="text-[10px] text-white/40 leading-relaxed pl-6" data-i18n="set_sound_desc">Habilita efectos de sonido al interactuar.</p>
                        </div>
                        <input type="checkbox" id="toggle_sound" class="toggle-checkbox" checked/>
                        <label for="toggle_sound" class="toggle-label" onclick="setTimeout(()=>AudioEngine.playClick(), 100)"></label>
                    </div>
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex-1 pr-4">
                            <span class="text-sm font-bold text-white block mb-1" data-i18n="set_vol"><i class="fa-solid fa-volume-low text-white/50 mr-2"></i>Volumen UI</span>
                            <p class="text-[10px] text-white/40 leading-relaxed pl-6" data-i18n="set_vol_desc">Ajusta la intensidad de los efectos.</p>
                        </div>
                        <input type="range" id="volume_slider" min="0" max="1" step="0.01" value="0.5" class="w-24" onchange="AudioEngine.updateVol(this.value)">
                    </div>
                    <div class="w-full h-px bg-white/10 mb-6 ml-6"></div>
                    <div class="flex items-start justify-between">
                        <div class="flex-1 pr-4">
                            <span class="text-sm font-bold text-white block mb-2" data-i18n="set_auto"><i class="fa-solid fa-download text-white/50 mr-2"></i>Auto-Instalar RPI</span>
                            <div class="ml-6 bg-black/30 p-3 rounded-xl border border-white/5">
                                <span class="text-[9px] text-white/70 font-bold block mb-1" data-i18n="set_auto_req">REQUISITOS:</span>
                                <ul class="text-[9px] text-white/40 list-disc pl-3 space-y-1">
                                    <li data-i18n="set_auto_li1">RPI abierto en PS4.</li>
                                    <li data-i18n="set_auto_li2">Solo archivos .pkg.</li>
                                </ul>
                            </div>
                        </div>
                        <input type="checkbox" id="toggle_autoinstall" class="toggle-checkbox"/>
                        <label for="toggle_autoinstall" class="toggle-label"></label>
                    </div>
                </div>
                <div class="text-center mt-8 opacity-40 mb-10">
                    <i class="fa-brands fa-playstation text-2xl mb-2 block"></i>
                    <p class="text-[9px] font-bold tracking-[0.2em]">GoldHen Manager v1.0</p>
                    <p class="text-[8px] font-mono mt-1">Developed by SeBaS</p>
                </div>
            </div>
        </main>

        <div class="floating-btn-global" id="floating-btn-ftp">
            <button onclick="document.getElementById('ftp-form-submit').click()" class="w-full btn-ps5-primary rounded-[1.5rem] py-5 font-black tracking-widest text-sm flex items-center justify-center gap-3">
                <i class="fa-brands fa-playstation text-xl"></i> <span data-i18n="btn_send_files">ENVIAR ARCHIVOS</span>
            </button>
        </div>

        <div class="floating-btn-global floating-hidden" id="floating-btn-aplicar">
            <button onclick="ejecutarFormIconos()" class="w-full btn-ps5-primary rounded-[1.5rem] py-5 font-black tracking-widest text-sm flex items-center justify-center gap-3">
                <i class="fa-solid fa-wand-magic-sparkles text-lg"></i> <span data-i18n="btn_apply_art">APLICAR PORTADA</span>
            </button>
        </div>

        <div class="floating-btn-global floating-hidden" id="floating-btn-payload">
            <button onclick="document.getElementById('payload-form-submit').click()" class="w-full btn-ps5-primary rounded-[1.5rem] py-5 font-black tracking-widest text-sm flex items-center justify-center gap-3">
                <i class="fa-solid fa-bolt text-lg"></i> <span data-i18n="btn_inject">INYECTAR PAYLOAD</span>
            </button>
        </div>

        <nav class="dock-nav">
            <button class="dock-item active" onclick="switchTab('tab-ftp', this, 0)" title="Transferir"><i class="fa-solid fa-exchange-alt"></i></button>
            <button class="dock-item" onclick="switchTab('tab-icons', this, 1)" title="Portadas"><i class="fa-solid fa-palette"></i></button>
            <button class="dock-item" onclick="switchTab('tab-explorer', this, 2)" title="Explorar"><i class="fa-solid fa-folder-tree"></i></button>
            <button class="dock-item" onclick="switchTab('tab-payloads', this, 3)" title="Payloads"><i class="fa-solid fa-microchip"></i></button>
            <button class="dock-item" onclick="switchTab('tab-settings', this, 4)" title="Ajustes"><i class="fa-solid fa-gear"></i></button>
        </nav>
    </div>

    <div id="overlay-sheet" class="overlay-sheet" onclick="closeItemOptions()"></div>
    <div id="bottom-sheet" class="bottom-sheet">
        <div class="w-12 h-1 bg-white/20 rounded-full mx-auto mt-3 mb-2"></div>
        <div class="px-6 pb-6">
            <h4 id="sheet-title" class="text-white font-bold text-sm mb-4 truncate border-b border-white/10 pb-4">...</h4>
            <div class="flex flex-col gap-2">
                <button onclick="renameCurrentItem()" class="flex items-center gap-4 p-4 rounded-2xl hover:bg-white/10 text-white text-left transition-colors"><i class="fa-solid fa-pen w-5 text-center text-white/50"></i> <span class="font-medium text-sm" data-i18n="opt_rename">Renombrar</span></button>
                <button onclick="cutCurrentItem()" class="flex items-center gap-4 p-4 rounded-2xl hover:bg-white/10 text-white text-left transition-colors"><i class="fa-solid fa-scissors w-5 text-center text-white/50"></i> <span class="font-medium text-sm" data-i18n="opt_move">Mover</span></button>
                <button onclick="deleteCurrentItem()" class="flex items-center gap-4 p-4 rounded-2xl hover:bg-red-500/20 text-red-400 text-left transition-colors mt-2 border border-red-500/20"><i class="fa-solid fa-trash w-5 text-center"></i> <span class="font-bold text-sm" data-i18n="opt_delete">Eliminar</span></button>
            </div>
        </div>
    </div>

    <div id="custom-modal" class="hidden fixed inset-0 modal-glass z-50 flex items-center justify-center px-5 opacity-0 transition-opacity duration-300">
        <div class="glass-panel border-white/20 rounded-[2.5rem] p-8 w-full max-w-sm text-center shadow-[0_0_50px_rgba(0,0,0,0.8)] relative transform scale-95 transition-transform duration-300" id="modal-card">
            <div id="modal-icon" class="w-20 h-20 mx-auto rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-6 relative"></div>
            <h3 id="modal-title" class="text-xl font-black text-white tracking-widest mb-2">...</h3>
            <div id="modal-text" class="text-xs text-white/60 mb-6 font-medium px-2 break-all leading-relaxed">...</div>
            
            <div id="modal-progress-container" class="w-full mb-4 hidden">
                <div class="w-full bg-black/50 rounded-full h-4 overflow-hidden border border-white/10 relative p-0.5">
                    <div id="modal-progress-bar" class="bg-white rounded-full h-full shadow-[0_0_10px_white] transition-all duration-300" style="width: 0%"></div>
                    <span id="modal-bytes" class="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-white mix-blend-difference tracking-widest"></span>
                </div>
                <div class="flex justify-between items-end mt-4 px-1">
                    <div class="flex flex-col items-start">
                        <span id="modal-speed" class="text-[10px] font-bold text-white/80 font-mono mb-1"><i class="fa-solid fa-bolt text-white/40"></i> -- MB/s</span>
                        <span id="modal-eta" class="text-[9px] font-bold text-white/50 font-mono"><i class="fa-solid fa-clock text-white/30"></i> ETA: --:--</span>
                    </div>
                    <span id="modal-percentage" class="text-2xl font-black text-white tracking-tighter">0%</span>
                </div>
            </div>
            
            <div id="modal-controls" class="flex gap-2 w-full mt-6 hidden">
                <button id="modal-action-btn" type="button" onclick="togglePauseResume()" class="flex-1 btn-ps5-primary rounded-2xl py-3.5 font-bold text-[10px] tracking-widest" data-i18n="modal_pause">PAUSAR</button>
                <button id="modal-cancel-btn" type="button" onclick="cancelarEnvio()" class="w-14 shrink-0 btn-ps5-danger rounded-2xl flex items-center justify-center"><i class="fa-solid fa-stop"></i></button>
            </div>
            <button id="modal-close-btn" type="button" onclick="closeCustomModal()" class="hidden w-full bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-2xl py-4 font-bold text-[11px] tracking-widest mt-6 transition-colors" data-i18n="modal_close">CERRAR</button>
        </div>
    </div>

    <div id="ps5-dialog" class="hidden fixed inset-0 modal-glass z-[100] flex items-center justify-center px-5 opacity-0 transition-opacity duration-300">
        <div class="glass-panel border-white/20 rounded-[2rem] p-6 w-full max-w-sm text-center shadow-[0_0_50px_rgba(0,0,0,0.8)] relative transform scale-95 transition-transform duration-300" id="ps5-dialog-card">
            <div id="ps5-dialog-icon" class="w-16 h-16 mx-auto rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-4 relative"></div>
            <h3 id="ps5-dialog-title" class="text-lg font-black text-white tracking-widest mb-2">TITULO</h3>
            <div id="ps5-dialog-text" class="text-[11px] text-white/60 mb-6 font-medium px-2 break-words leading-relaxed">Mensaje...</div>
            <input type="text" id="ps5-dialog-input" class="hidden w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 mb-6 text-white text-sm font-mono outline-none focus:border-white/30 transition-colors" autocomplete="off" />
            <div class="flex gap-2 w-full">
                <button id="ps5-dialog-btn-cancel" class="hidden flex-1 bg-white/10 hover:bg-white/20 border border-white/10 text-white rounded-xl py-3.5 font-bold text-[10px] tracking-widest transition-colors" data-i18n="modal_cancel">CANCELAR</button>
                <button id="ps5-dialog-btn-confirm" class="flex-1 bg-white text-black rounded-xl py-3.5 font-bold text-[10px] tracking-widest hover:bg-gray-200 transition-all shadow-[0_0_15px_rgba(255,255,255,0.2)]" data-i18n="modal_accept">ACEPTAR</button>
            </div>
        </div>
    </div>

    <script>
        // ==========================================
        // INTRO PS5 (PARTÍCULAS Y ANIMACIÓN)
        // ==========================================
        const canvas = document.getElementById('stardust');
        const ctx = canvas.getContext('2d');
        let particles = [];
        let isExploding = false;

        function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
        window.addEventListener('resize', resize); resize();

        class Particle {
            constructor() { this.reset(); }
            reset() {
                this.x = Math.random() * canvas.width; this.y = Math.random() * canvas.height;
                this.size = Math.random() * 1.5 + 0.1;
                this.speedX = (Math.random() - 0.5) * 0.4; this.speedY = (Math.random() - 0.5) * 0.4;
                this.opacity = Math.random() * 0.5;
            }
            update() {
                if (isExploding) {
                    let dx = this.x - canvas.width / 2; let dy = this.y - canvas.height / 2;
                    this.x += dx * 0.08; this.y += dy * 0.08;
                    this.size *= 1.02; this.opacity -= 0.015;
                } else {
                    this.x += this.speedX; this.y += this.speedY;
                    if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) this.reset();
                }
            }
            draw() {
                ctx.fillStyle = `rgba(255, 255, 255, ${Math.max(0, this.opacity)})`;
                ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2); ctx.fill();
            }
        }
        for (let i = 0; i < 150; i++) particles.push(new Particle());
        
        function animateParticles() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            particles.forEach(p => { p.update(); p.draw(); });
            if(!isExploding || particles.some(p => p.opacity > 0)) requestAnimationFrame(animateParticles);
        }

        // ==========================================
        // VARIABLES GLOBALES DE APP
        // ==========================================
        let isTransferring = false; let uploadAbortController = null; let isPaused = false; let currentFileName = ""; const CHUNK_SIZE = 20 * 1024 * 1024; 

        // ==========================================
        // SISTEMA MULTI-IDIOMA (i18n)
        // ==========================================
        const i18n = {
            es: {
                ps4_detected: "PS4 DETECTADA", ps4_disconnected: "DESCONECTADA", searching: "BUSCANDO...",
                tab_transfer: "Transferir", desc_transfer: "Envía juegos o aplicaciones a tu consola.",
                dest_routes: '<i class="fa-solid fa-folder-open mr-2"></i>RUTAS DE DESTINO',
                files_pkg: '<i class="fa-solid fa-file-circle-plus mr-2"></i>ARCHIVOS (PKG/BIN)',
                touch_select: "TOCA PARA SELECCIONAR", btn_send_files: "ENVIAR ARCHIVOS",
                tab_mod: "Modding", desc_mod: "Personaliza el arte de tu biblioteca.",
                gallery: "GALERÍA", import: "IMPORTAR", local: "LOCAL", btn_apply_art: "APLICAR PORTADA",
                import_desc: "Pega un link directo de imagen o carpeta de GitHub para descargarla a tu galería.", btn_import: "INICIAR IMPORTACIÓN",
                touch_image: "TOCA PARA BUSCAR IMAGEN",
                tab_exp: "Explorador", desc_exp: "Gestor de archivos interno.", btn_paste: "PEGAR", btn_delete: "ELIMINAR",
                config_ip: "Configura tu IP para explorar.",
                tab_pay: "Payloads", desc_pay: "Inyección de código BinLoader.", local_port: "PUERTO LOCAL",
                device: "DISPOSITIVO", touch_bin: "TOCA PARA BUSCAR .BIN", btn_inject: "INYECTAR PAYLOAD",
                tab_set: "Ajustes", desc_set: "Configuración del sistema.",
                set_lang: '<i class="fa-solid fa-language text-white/50 mr-2"></i>Idioma / Language', set_lang_desc: "Cambia el idioma de la interfaz.",
                install_app: "Instalar App", install_desc: "Añadir a pantalla de inicio", btn_install: "INSTALAR",
                set_wake: '<i class="fa-solid fa-lock text-white/50 mr-2"></i>Pantalla Activa', set_wake_desc: "Evita que el dispositivo se apague durante transferencias largas.",
                set_sound: '<i class="fa-solid fa-bell text-white/50 mr-2"></i>Sonidos UI', set_sound_desc: "Habilita efectos de sonido al interactuar.",
                set_vol: '<i class="fa-solid fa-volume-low text-white/50 mr-2"></i>Volumen UI', set_vol_desc: "Ajusta la intensidad de los efectos.",
                set_auto: '<i class="fa-solid fa-download text-white/50 mr-2"></i>Auto-Instalar RPI', set_auto_req: "REQUISITOS:",
                set_auto_li1: "RPI abierto en PS4.", set_auto_li2: "Solo archivos .pkg.",
                opt_rename: "Renombrar", opt_move: "Mover", opt_delete: "Eliminar",
                modal_pause: "PAUSAR", modal_close: "CERRAR", modal_cancel: "CANCELAR", modal_accept: "ACEPTAR",
                j_err_ip: "FALTA IP", j_err_ip_m: "Por favor, escribe o busca la IP de tu PS4 arriba antes de enviar archivos.",
                j_err_file: "FALTA ARCHIVO", j_err_file_m: "Toca el cuadro gris grande para elegir qué juego o app quieres enviar.",
                j_prep: "PREPARANDO", j_prep_m: "Analizando disco duro...", j_resume: "REANUDAR",
                j_resume_m: "Archivo incompleto detectado.<br>¿Deseas reanudar la subida de",
                j_exist: "ARCHIVO EXISTENTE", j_exist_m: "ya existe en la PS4.<br>¿Deseas sobrescribirlo por completo?",
                j_cancel: "CANCELADO", j_cancel_m: "Transferencia abortada.", j_comp: "COMPLETADO",
                j_comp_m: "Archivos transferidos con éxito.", j_inj: "INYECCIÓN", j_inj_m: "Conectando al BinLoader...",
                j_succ: "ÉXITO", j_err: "ERROR", j_del_sel: "ELIMINAR SELECCIÓN",
                j_del_m1: "¿Estás seguro de querer eliminar", j_elem: "elementos", j_warn: "⚠️ ADVERTENCIA FINAL",
                j_warn_m: "¿Confirmas esta acción?<br><br>¡Borrar archivos del sistema directamente desde aquí podría dañar tu consola de forma irreversible! Esta acción NO se puede deshacer.",
                j_del_prog: "Borrando", j_del_part: "ELIMINACIÓN PARCIAL", j_del_part_m: "Algunas carpetas no estaban vacías o están protegidas.",
                j_ren: "RENOMBRAR", j_ren_m: "Introduce un nuevo nombre para:", j_err_paste: "ERROR AL PEGAR",
                j_del1: "¿Eliminar", j_new_fold: "NUEVA CARPETA", j_new_fold_m: "Introduce el nombre de la carpeta a crear:",
                j_scan_fail: "ESCANEO FALLIDO", j_scan_fail_m: "No se encontró la PS4 en la red local. Revisa la conexión.",
                j_del_route: "ELIMINAR RUTA", j_del_route_m: "¿Seguro que deseas quitar la ruta de destino",
                j_files_sel: "ARCHIVOS SELECCIONADOS", j_fav_rem: "QUITAR FAVORITO", j_fav_rem_m: "¿Deseas quitar el acceso directo a la carpeta",
                j_err_net: "Error de red", j_empty: "Carpeta vacía", j_sel: "seleccionados",
                empty_payloads: 'Coloca tus archivos <b>.bin</b> dentro de la carpeta <br><span class="font-mono text-white/60">htdocs/payloads/</span> en tu explorador de archivos de Android para que aparezcan aquí automáticamente.',
                empty_icons: 'Aún no hay imágenes aquí.'
            },
            en: {
                ps4_detected: "PS4 DETECTED", ps4_disconnected: "DISCONNECTED", searching: "SEARCHING...",
                tab_transfer: "Transfer", desc_transfer: "Send games or apps to your console.",
                dest_routes: '<i class="fa-solid fa-folder-open mr-2"></i>DESTINATION PATHS',
                files_pkg: '<i class="fa-solid fa-file-circle-plus mr-2"></i>FILES (PKG/BIN)',
                touch_select: "TAP TO SELECT", btn_send_files: "SEND FILES",
                tab_mod: "Modding", desc_mod: "Customize your library artwork.",
                gallery: "GALLERY", import: "IMPORT", local: "LOCAL", btn_apply_art: "APPLY ARTWORK",
                import_desc: "Paste a direct image link or GitHub folder to download to your gallery.", btn_import: "START IMPORT",
                touch_image: "TAP TO BROWSE IMAGE",
                tab_exp: "Explorer", desc_exp: "Internal file manager.", btn_paste: "PASTE", btn_delete: "DELETE",
                config_ip: "Set your IP to explore.",
                tab_pay: "Payloads", desc_pay: "BinLoader code injection.", local_port: "LOCAL PORT",
                device: "DEVICE", touch_bin: "TAP TO BROWSE .BIN", btn_inject: "INJECT PAYLOAD",
                tab_set: "Settings", desc_set: "System configuration.",
                set_lang: '<i class="fa-solid fa-language text-white/50 mr-2"></i>Language / Idioma', set_lang_desc: "Change the interface language.",
                install_app: "Install App", install_desc: "Add to home screen", btn_install: "INSTALL",
                set_wake: '<i class="fa-solid fa-lock text-white/50 mr-2"></i>Keep Screen On', set_wake_desc: "Prevents device sleep during long transfers.",
                set_sound: '<i class="fa-solid fa-bell text-white/50 mr-2"></i>UI Sounds', set_sound_desc: "Enable interactive sound effects.",
                set_vol: '<i class="fa-solid fa-volume-low text-white/50 mr-2"></i>UI Volume', set_vol_desc: "Adjust the intensity of effects.",
                set_auto: '<i class="fa-solid fa-download text-white/50 mr-2"></i>Auto-Install RPI', set_auto_req: "REQUIREMENTS:",
                set_auto_li1: "RPI open on PS4.", set_auto_li2: "Only .pkg files.",
                opt_rename: "Rename", opt_move: "Move", opt_delete: "Delete",
                modal_pause: "PAUSE", modal_close: "CLOSE", modal_cancel: "CANCEL", modal_accept: "ACCEPT",
                j_err_ip: "MISSING IP", j_err_ip_m: "Please type or scan your PS4 IP above before sending files.",
                j_err_file: "MISSING FILE", j_err_file_m: "Tap the large gray box to choose which game or app you want to send.",
                j_prep: "PREPARING", j_prep_m: "Analyzing hard drive...", j_resume: "RESUME",
                j_resume_m: "Incomplete file detected.<br>Do you want to resume the upload of",
                j_exist: "FILE EXISTS", j_exist_m: "already exists.<br>Do you want to completely overwrite it?",
                j_cancel: "CANCELED", j_cancel_m: "Transfer aborted.", j_comp: "COMPLETED",
                j_comp_m: "Files transferred successfully.", j_inj: "INJECTING", j_inj_m: "Connecting to BinLoader...",
                j_succ: "SUCCESS", j_err: "ERROR", j_del_sel: "DELETE SELECTION",
                j_del_m1: "Are you sure you want to delete", j_elem: "items", j_warn: "⚠️ FINAL WARNING",
                j_warn_m: "Do you confirm this action?<br><br>Deleting system files directly from here could permanently damage your console! This cannot be undone.",
                j_del_prog: "Deleting", j_del_part: "PARTIAL DELETION", j_del_part_m: "Some folders were not empty or are protected.",
                j_ren: "RENAME", j_ren_m: "Enter a new name for:", j_err_paste: "PASTE ERROR",
                j_del1: "Delete", j_new_fold: "NEW FOLDER", j_new_fold_m: "Enter the name of the folder to create:",
                j_scan_fail: "SCAN FAILED", j_scan_fail_m: "PS4 not found on local network. Check connection.",
                j_del_route: "DELETE PATH", j_del_route_m: "Are you sure you want to remove the destination path",
                j_files_sel: "FILES SELECTED", j_fav_rem: "REMOVE SHORTCUT", j_fav_rem_m: "Do you want to remove the shortcut for the folder",
                j_err_net: "Network error", j_empty: "Empty folder", j_sel: "selected",
                empty_payloads: 'Place your <b>.bin</b> files inside the folder <br><span class="font-mono text-white/60">htdocs/payloads/</span> in your Android file explorer to make them appear here automatically.',
                empty_icons: 'There are no images here yet.'
            }
        };

        let currentLang = 'es';
        function setLanguage(lang) {
            currentLang = lang;
            localStorage.setItem('ps4_ui_lang', lang);
            
            const btnEs = document.getElementById('btn-lang-es');
            const btnEn = document.getElementById('btn-lang-en');
            if(lang === 'es') {
                btnEs.className = "px-4 py-2 text-[10px] font-bold rounded-lg bg-white text-black shadow-lg transition-all";
                btnEn.className = "px-4 py-2 text-[10px] font-bold rounded-lg text-white/50 hover:text-white transition-all";
            } else {
                btnEn.className = "px-4 py-2 text-[10px] font-bold rounded-lg bg-white text-black shadow-lg transition-all";
                btnEs.className = "px-4 py-2 text-[10px] font-bold rounded-lg text-white/50 hover:text-white transition-all";
            }

            document.querySelectorAll('[data-i18n]').forEach(el => {
                const key = el.getAttribute('data-i18n');
                if (i18n[lang][key]) el.innerHTML = i18n[lang][key];
            });

            updateFileName(document.getElementById('file-upload'));
            if(document.getElementById('explorer-list').innerHTML.includes('fa-folder-tree')) {
                document.getElementById('explorer-list').innerHTML = `<div class="text-center text-white/30 text-xs py-20"><i class="fa-solid fa-folder-tree text-4xl mb-4 block opacity-50"></i><span data-i18n="config_ip">${i18n[lang].config_ip}</span></div>`;
            }
            if(isSelectMode) document.getElementById('multi-select-count').innerText = `${selectedItems.length} ${i18n[lang].j_sel}`;
        }
        function t(key) { return i18n[currentLang][key] || key; }

        // ==========================================
        // AUDIO ENGINE
        // ==========================================
        const AudioEngine = {
            ctx: null, globalVol: 0.5,
            init: function() { if (!document.getElementById('toggle_sound').checked) return; if (!this.ctx) { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } if (this.ctx.state === 'suspended') this.ctx.resume(); },
            loadSavedVol: function() { let saved = localStorage.getItem('ps4_ui_vol'); if(saved !== null) { this.globalVol = parseFloat(saved); document.getElementById('volume_slider').value = this.globalVol; } },
            updateVol: function(v) { this.globalVol = parseFloat(v); localStorage.setItem('ps4_ui_vol', this.globalVol); this.playClick(); },
            playTone: function(freq, type, duration, vol=0.5, slideFreq=null) { if (!document.getElementById('toggle_sound').checked) return; this.init(); if (!this.ctx) return; const finalVol = vol * this.globalVol; if (finalVol <= 0) return; const osc = this.ctx.createOscillator(); const gain = this.ctx.createGain(); osc.type = type; osc.frequency.setValueAtTime(freq, this.ctx.currentTime); if (slideFreq) { osc.frequency.exponentialRampToValueAtTime(slideFreq, this.ctx.currentTime + (duration * 0.5)); } gain.gain.setValueAtTime(0, this.ctx.currentTime); gain.gain.linearRampToValueAtTime(finalVol, this.ctx.currentTime + 0.02); gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration); osc.connect(gain); gain.connect(this.ctx.destination); osc.start(); osc.stop(this.ctx.currentTime + duration); },
            playClick: function() { if (!document.getElementById('toggle_sound').checked) return; this.init(); if (!this.ctx) return; const finalVol = 0.8 * this.globalVol; if (finalVol <= 0) return; const duration = 0.04; const osc = this.ctx.createOscillator(); const gain = this.ctx.createGain(); osc.type = 'sine'; osc.frequency.setValueAtTime(1800, this.ctx.currentTime); osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + duration); gain.gain.setValueAtTime(0, this.ctx.currentTime); gain.gain.linearRampToValueAtTime(finalVol, this.ctx.currentTime + 0.002); gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration); osc.connect(gain); gain.connect(this.ctx.destination); osc.start(); osc.stop(this.ctx.currentTime + duration); },     
            playSuccess: function() { this.playTone(523.25, 'sine', 0.8, 0.6); setTimeout(() => this.playTone(659.25, 'sine', 0.8, 0.6), 80); setTimeout(() => this.playTone(783.99, 'sine', 1.2, 0.7), 160); },
            playError: function() { this.playTone(200, 'triangle', 0.2, 0.9, 150); setTimeout(() => this.playTone(200, 'triangle', 0.3, 0.9, 150), 180); },
            playDisconnect: function() { this.playTone(350, 'triangle', 0.3, 0.7, 200); setTimeout(() => this.playTone(200, 'sawtooth', 0.5, 0.8, 80), 250); },
            playPS5Boot: function() {
                if (!document.getElementById('toggle_sound').checked) return; 
                this.init(); if (!this.ctx) return; 
                const freqs = [150, 225, 300, 450]; 
                freqs.forEach((freq, i) => {
                    const osc = this.ctx.createOscillator(); const gain = this.ctx.createGain(); 
                    osc.type = i % 2 === 0 ? 'sine' : 'triangle'; 
                    osc.frequency.setValueAtTime(freq, this.ctx.currentTime); 
                    gain.gain.setValueAtTime(0, this.ctx.currentTime); 
                    gain.gain.linearRampToValueAtTime(0.12 * this.globalVol, this.ctx.currentTime + 1.5); 
                    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 4.5); 
                    osc.connect(gain); gain.connect(this.ctx.destination); 
                    osc.start(); osc.stop(this.ctx.currentTime + 5); 
                });
            }
        };
        document.addEventListener('touchstart', () => AudioEngine.init(), {once:true});
        document.addEventListener('click', (e) => { const isButton = e.target.closest('button, .dock-item, .gallery-item, .folder-btn, .cursor-pointer, input[type="checkbox"]'); if(isButton && document.getElementById('toggle_sound').checked && e.target.id !== 'volume_slider') { AudioEngine.playClick(); } });

        // ==========================================
        // DIÁLOGOS NATIVOS PS5
        // ==========================================
        const dialogEl = document.getElementById('ps5-dialog'), dialogCard = document.getElementById('ps5-dialog-card'), dialogTitle = document.getElementById('ps5-dialog-title'), dialogText = document.getElementById('ps5-dialog-text'), dialogIcon = document.getElementById('ps5-dialog-icon'), dialogInput = document.getElementById('ps5-dialog-input'), dialogBtnCancel = document.getElementById('ps5-dialog-btn-cancel'), dialogBtnConfirm = document.getElementById('ps5-dialog-btn-confirm');
        function showPS5Dialog(title, message, type = 'alert', iconClass = 'fa-info', inputValue = '', confirmColor = 'bg-white text-black') {
            return new Promise((resolve) => {
                if(type === 'alert' && iconClass.includes('text-red')) AudioEngine.playError();
                else if (type === 'confirm' && confirmColor.includes('bg-red')) AudioEngine.playError();
                
                dialogTitle.innerText = title; dialogText.innerHTML = message; dialogIcon.innerHTML = `<i class="fa-solid ${iconClass} text-2xl text-white"></i>`;
                dialogInput.classList.add('hidden'); dialogBtnCancel.classList.add('hidden');
                dialogBtnConfirm.className = `flex-1 rounded-xl py-3.5 font-bold text-[10px] tracking-widest transition-all shadow-lg active:scale-95 ${confirmColor}`;
                dialogBtnCancel.innerText = t('modal_cancel'); dialogBtnConfirm.innerText = t('modal_accept');

                if (type === 'prompt') { dialogInput.classList.remove('hidden'); dialogInput.value = inputValue; dialogBtnCancel.classList.remove('hidden'); setTimeout(() => dialogInput.focus(), 300); } 
                else if (type === 'confirm') { dialogBtnCancel.classList.remove('hidden'); }

                const closeDialog = (result) => { dialogEl.classList.add('opacity-0'); dialogCard.classList.add('scale-95'); setTimeout(() => { dialogEl.classList.add('hidden'); resolve(result); }, 300); };
                dialogBtnConfirm.onclick = () => { if (type === 'prompt') closeDialog(dialogInput.value.trim()); else closeDialog(true); };
                dialogBtnCancel.onclick = () => closeDialog(false);

                dialogEl.classList.remove('hidden'); setTimeout(() => { dialogEl.classList.remove('opacity-0'); dialogCard.classList.remove('scale-95'); }, 10);
            });
        }
        const ps5Alert = (title, msg, icon='fa-info') => showPS5Dialog(title, msg, 'alert', icon);
        const ps5Confirm = (title, msg, icon='fa-circle-question', confirmColor='bg-white text-black') => showPS5Dialog(title, msg, 'confirm', icon, '', confirmColor);
        const ps5Prompt = (title, msg, defaultVal='') => showPS5Dialog(title, msg, 'prompt', 'fa-pen', defaultVal);

        // ==========================================
        // ARRANQUE Y LÓGICA DEL INTRO AUTOMÁTICO
        // ==========================================
        window.addEventListener('load', () => {
            const savedLang = localStorage.getItem('ps4_ui_lang') || 'es';
            setLanguage(savedLang);
            AudioEngine.loadSavedVol();
            
            // Inicia el loop de partículas
            animateParticles();
            
            const introScreen = document.getElementById('intro-screen');
            const logoWrap = document.getElementById('logo-wrapper');
            const appUi = document.getElementById('app-ui');
            const ambientBg = document.getElementById('ambient-bg');
            
            // 1. Aparece el Logo
            setTimeout(() => {
                logoWrap.style.opacity = '1';
                logoWrap.style.transform = 'scale(1)';
                logoWrap.style.filter = 'blur(0px)';
            }, 500);

            // 2. Intentar reproducir audio (Puede ser bloqueado por el navegador si es la primera vez)
            setTimeout(() => { try { AudioEngine.playPS5Boot(); } catch(e) {} }, 500);

            // 3. Explosión "Warp Speed"
            setTimeout(() => {
                isExploding = true;
                logoWrap.style.transform = 'scale(1.5)';
                logoWrap.style.opacity = '0';
                logoWrap.style.filter = 'blur(20px)';
                
                // 4. Mostrar la app principal con transición suave Parallax
                setTimeout(() => {
                    introScreen.style.opacity = '0';
                    appUi.style.opacity = '1';
                    ambientBg.style.transform = 'scale(1)'; // Hace zoom-out el fondo
                    
                    // Borramos el canvas para liberar memoria
                    setTimeout(() => { introScreen.remove(); }, 1500);
                }, 800);
            }, 3000);
        });

        // ==========================================
        // GESTIÓN FTP Y CARPETAS
        // ==========================================
        const hiddenPathInput = document.getElementById('selected-path-input');
        function selectPath(btn, path) { document.querySelectorAll('.folder-btn').forEach(el => el.classList.remove('active')); btn.classList.add('active'); hiddenPathInput.value = path; }
        function showAddPathUI() { document.getElementById('add-path-ui').classList.remove('hidden'); }
        function hideAddPathUI() { document.getElementById('add-path-ui').classList.add('hidden'); document.getElementById('new-path-input').value = ''; }
        function saveNewPath() { let inputPath = document.getElementById('new-path-input').value.trim(); if (!inputPath) return; if (!inputPath.startsWith('/')) inputPath = '/' + inputPath; if (!inputPath.endsWith('/')) inputPath = inputPath + '/'; crearBotonCarpeta(inputPath, true); hideAddPathUI(); }
        function crearBotonCarpeta(path, isNew = false) {
            const grid = document.getElementById('paths-grid'); const btnAdd = document.getElementById('btn-otra');
            const btnContainer = document.createElement('div'); btnContainer.className = 'relative group h-full flex';
            btnContainer.innerHTML = `<button type="button" class="folder-btn btn-ps5 rounded-xl py-3 w-full text-[10px] font-bold text-white/60 border border-white/10 break-all px-2 pr-6" onclick="selectPath(this, '${path}')">${path}</button><div onclick="deleteCustomFolder('${path}', this.parentElement)" class="absolute top-1 right-1 w-5 h-5 flex items-center justify-center bg-red-500/80 rounded-full text-white cursor-pointer opacity-80 hover:opacity-100 z-10 transition-opacity"><i class="fa-solid fa-xmark text-[10px]"></i></div>`;
            grid.insertBefore(btnContainer, btnAdd);
            if (isNew) { selectPath(btnContainer.querySelector('.folder-btn'), path); let savedFolders = JSON.parse(localStorage.getItem('ps4_custom_folders')) || []; if (!savedFolders.includes(path)) { savedFolders.push(path); localStorage.setItem('ps4_custom_folders', JSON.stringify(savedFolders)); } }
        }
        async function deleteCustomFolder(path, containerDiv) {
            const confirmado = await ps5Confirm(t('j_del_route'), `${t('j_del_route_m')} <br><b class="text-white font-mono mt-2 block">${path}</b>?`, 'fa-folder-minus', 'bg-red-500 text-white border border-red-400');
            if(!confirmado) return;
            containerDiv.remove();
            let savedFolders = JSON.parse(localStorage.getItem('ps4_custom_folders')) || []; savedFolders = savedFolders.filter(p => p !== path); localStorage.setItem('ps4_custom_folders', JSON.stringify(savedFolders));
            if (hiddenPathInput.value === path) { const defaultBtn = document.querySelector('.folder-btn'); if(defaultBtn) defaultBtn.click(); }
        }
        function updateFileName(input) {
            const display = document.getElementById('file-name-display'); const iconContainer = document.getElementById('upload-icon-container');
            if (input && input.files && input.files.length > 0) {
                if (input.files.length === 1) { display.innerText = input.files[0].name; } else { display.innerText = input.files.length + " " + t('j_files_sel'); }
                display.classList.replace('text-white/50', 'text-white'); iconContainer.innerHTML = '<i class="fa-solid fa-check text-2xl text-black"></i>'; iconContainer.classList.replace('bg-white/5', 'bg-white'); iconContainer.classList.replace('text-white', 'text-black');
            } else if(display) {
                display.innerText = t('touch_select'); display.classList.replace('text-white', 'text-white/50'); iconContainer.innerHTML = '<i class="fa-solid fa-cloud-arrow-up text-2xl"></i>'; iconContainer.classList.replace('bg-white', 'bg-white/5'); iconContainer.classList.replace('text-black', 'text-white');
            }
        }

        // ==========================================
        // PWA Y NAVEGACIÓN
        // ==========================================
        let deferredPrompt; const installContainer = document.getElementById('install-pwa-container');
        window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredPrompt = e; if (installContainer) installContainer.classList.remove('hidden'); });
        async function installPWA() { if (!deferredPrompt) return; deferredPrompt.prompt(); const { outcome } = await deferredPrompt.userChoice; if (outcome === 'accepted' && installContainer) { installContainer.classList.add('hidden'); } deferredPrompt = null; }
        function dismissPWA() { if (installContainer) { installContainer.classList.add('opacity-0', 'scale-95'); setTimeout(() => installContainer.classList.add('hidden'), 300); } }
        window.addEventListener('appinstalled', (e) => { if (installContainer) installContainer.classList.add('hidden'); });

        let touchstartX = 0, touchendX = 0, touchstartY = 0, touchendY = 0; const tabsOrder = ['tab-ftp', 'tab-icons', 'tab-explorer', 'tab-payloads', 'tab-settings']; let currentTabIndex = 0;
        document.addEventListener('touchstart', e => { touchstartX = e.changedTouches[0].screenX; touchstartY = e.changedTouches[0].screenY; }, {passive: true});
        document.addEventListener('touchend', e => { touchendX = e.changedTouches[0].screenX; touchendY = e.changedTouches[0].screenY; handleSwipe(); }, {passive: true});
        function handleSwipe() {
            if(!document.getElementById('custom-modal').classList.contains('hidden') || !document.getElementById('ps5-dialog').classList.contains('hidden') || document.getElementById('bottom-sheet').classList.contains('open')) return;
            const deltaX = touchendX - touchstartX; const deltaY = touchendY - touchstartY;
            if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 60) {
                const navButtons = document.querySelectorAll('.dock-item');
                if (deltaX < 0) { if (currentTabIndex < tabsOrder.length - 1) { currentTabIndex++; switchTab(tabsOrder[currentTabIndex], navButtons[currentTabIndex], currentTabIndex); } } 
                else { if (currentTabIndex > 0) { currentTabIndex--; switchTab(tabsOrder[currentTabIndex], navButtons[currentTabIndex], currentTabIndex); } }
            }
        }
        function switchTab(tabId, btnElement, targetIndex = null) {
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active')); document.querySelectorAll('.dock-item').forEach(b => b.classList.remove('active'));
            const targetView = document.getElementById(tabId); btnElement.classList.add('active'); window.scrollTo({ top: 0, behavior: 'smooth' });
            if(targetIndex !== null) currentTabIndex = targetIndex; else currentTabIndex = tabsOrder.indexOf(tabId);
            setTimeout(() => { targetView.classList.add('active'); }, 50);
            
            const btnFtp = document.getElementById('floating-btn-ftp'), btnAplicar = document.getElementById('floating-btn-aplicar'), btnPayload = document.getElementById('floating-btn-payload');
            if(btnFtp) btnFtp.classList.add('floating-hidden'); if(btnAplicar) btnAplicar.classList.add('floating-hidden'); if(btnPayload) btnPayload.classList.add('floating-hidden');
            
            if (tabId === 'tab-ftp') { if(btnFtp) btnFtp.classList.remove('floating-hidden'); } 
            else if (tabId === 'tab-icons' && currentIconSource !== 'import') { if(btnAplicar) btnAplicar.classList.remove('floating-hidden'); } 
            else if (tabId === 'tab-payloads') { if(btnPayload) btnPayload.classList.remove('floating-hidden'); }
            if (tabId === 'tab-explorer' && currentExplorerPath === '') { loadExplorerPath('/'); }
        }

        // ==========================================
        // SISTEMA DE GALERÍAS Y MODDING
        // ==========================================
        let PAYLOADS_LOCALES = <?php echo json_encode($payloads_locales); ?>; let selectedPayloadValue = '';
        function cargarGaleriaPayloads() {
            const container = document.getElementById('payload-gallery-container');
            if (!PAYLOADS_LOCALES || PAYLOADS_LOCALES.length === 0) { 
                container.className = 'bg-black/20 border border-white/5 rounded-[1.5rem] p-3 h-[250px] flex flex-col items-center justify-center text-center'; 
                container.innerHTML = `<i class="fa-solid fa-folder text-4xl mb-3 block text-white/20"></i><span class="text-white/40 text-[10px] leading-relaxed px-4" data-i18n="empty_payloads">${t('empty_payloads')}</span>`; 
                return; 
            }
            container.className = 'bg-black/20 border border-white/5 rounded-[1.5rem] p-3 h-[250px] overflow-y-auto custom-scrollbar flex flex-col gap-2'; let htmlStr = '';
            PAYLOADS_LOCALES.forEach(item => { const urlClean = item.url.replace(/'/g, "\\'"); htmlStr += `<div class="payload-item bg-white/5 border border-white/10 rounded-2xl p-4 cursor-pointer flex items-center gap-4 transition-all" onclick="seleccionarPayloadGaleria(this, '${urlClean}')"><div class="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center shrink-0"><i class="fa-solid fa-microchip text-white"></i></div><div class="flex-1 overflow-hidden"><span class="text-sm text-white font-bold block truncate tracking-wide">${item.nombre}</span><span class="text-[9px] text-white/40 font-mono mt-0.5" data-i18n="touch_select">Toca para seleccionar</span></div><i class="fa-solid fa-circle-check text-white opacity-0 transition-opacity check-icon text-lg"></i></div>`; });
            container.innerHTML = htmlStr;
        }

        const APP_PRINCIPAL_CUSA = "CUSA99999"; 
        let ICONOS_LOCALES = <?php echo json_encode($iconos_locales); ?>; 
        let BACKUPS_LOCALES = <?php echo json_encode($backups_locales); ?>; 
        let selectedIconType = "", selectedIconValue = "";

        function cargarGaleria(items, containerId, tipoCarpeta) { 
            const container = document.getElementById(containerId); 
            if (!items || items.length === 0) { 
                container.className = 'bg-black/20 border border-white/5 rounded-[1.5rem] p-3 h-[250px] flex flex-col items-center justify-center text-center'; 
                container.innerHTML = `<i class="fa-solid fa-folder-open text-4xl mb-3 block text-white/20"></i><span class="text-white/40 text-[10px] leading-relaxed px-4">${t('empty_icons')}</span>`; 
                return; 
            } 
            container.className = 'bg-black/20 border border-white/5 rounded-[1.5rem] p-3 h-[250px] overflow-y-auto custom-scrollbar grid grid-cols-3 gap-3 content-start'; 
            let htmlStr = '';
            items.forEach((item) => { 
                if(!item.url) return; 
                const urlClean = item.url.replace(/'/g, "\\'"); 
                htmlStr += `
                <div class="gallery-item group relative" onclick="seleccionarIconoGaleria(this, 'local_gallery', '${urlClean}')">
                    <img src="${item.url}?v=${Date.now()}" alt="${item.nombre}" loading="lazy" class="w-full h-full object-cover rounded-xl">
                    <button type="button" onclick="eliminarImagenGaleria(event, '${item.nombre}', '${tipoCarpeta}')" class="absolute top-1 right-1 w-7 h-7 bg-red-600/90 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all z-30 hover:bg-red-500 hover:scale-110 shadow-lg">
                        <i class="fa-solid fa-trash text-[10px]"></i>
                    </button>
                </div>`; 
            }); 
            container.innerHTML = htmlStr;
        }

        function seleccionarPayloadGaleria(elemento, url) { document.querySelectorAll('.payload-item').forEach(el => { el.classList.remove('selected'); el.querySelector('.check-icon').classList.add('opacity-0'); }); elemento.classList.add('selected'); elemento.querySelector('.check-icon').classList.remove('opacity-0'); selectedPayloadValue = url; }
        function seleccionarIconoGaleria(elementoDiv, tipo, urlODireccion) { document.querySelectorAll('.gallery-item').forEach(el => el.classList.remove('selected')); elementoDiv.classList.add('selected'); selectedIconType = tipo; selectedIconValue = urlODireccion; const cusaInput = document.getElementById('icon-cusa'); if(!cusaInput.value) cusaInput.value = APP_PRINCIPAL_CUSA; }

        let currentIconSource = 'gallery';
        function switchIconSource(type) {
            currentIconSource = type; 
            const bG = document.getElementById('btn-src-gallery'), bB = document.getElementById('btn-src-backup'), bI = document.getElementById('btn-src-import'), bL = document.getElementById('btn-src-local'); 
            const bxG = document.getElementById('box-src-gallery'), bxB = document.getElementById('box-src-backup'), bxI = document.getElementById('box-src-import'), bxL = document.getElementById('box-src-local'); 
            const btnFlotante = document.getElementById('floating-btn-aplicar');
            
            [bG, bB, bI, bL].forEach(b => { b.className = "flex-1 py-3 px-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors whitespace-nowrap"; }); 
            [bxG, bxB, bxI, bxL].forEach(b => b.classList.add('hidden'));
            
            const activeBtn = type === 'gallery' ? bG : (type === 'backup' ? bB : (type === 'import' ? bI : bL));
            activeBtn.className = "flex-1 py-3 px-3 text-[9px] font-bold tracking-widest rounded-xl bg-white text-black shadow-lg whitespace-nowrap"; 
            document.getElementById(`box-src-${type}`).classList.remove('hidden');
            
            if(btnFlotante) { if(type === 'import') btnFlotante.classList.add('floating-hidden'); else btnFlotante.classList.remove('floating-hidden'); }
            
            if(type === 'gallery') actualizarGaleria();
            if(type === 'backup') actualizarBackups();
        }

        let currentPayloadSource = 'gallery';
        function switchPayloadSource(type) {
            currentPayloadSource = type; const bG = document.getElementById('btn-pay-gallery'), bL = document.getElementById('btn-pay-local'); const bxG = document.getElementById('box-pay-gallery'), bxL = document.getElementById('box-pay-local');
            [bG, bL].forEach(b => { b.className = "flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors"; }); [bxG, bxL].forEach(b => b.classList.add('hidden'));
            const activeBtn = type === 'gallery' ? bG : bL;
            activeBtn.className = "flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl bg-white text-black shadow-lg"; document.getElementById(`box-pay-${type}`).classList.remove('hidden');
        }

        function updatePayloadName(input) {
            const display = document.getElementById('payload-name-display'); const iconContainer = document.getElementById('payload-icon-container');
            if (input.files && input.files.length > 0) { display.innerText = input.files[0].name; display.classList.replace('text-white/50', 'text-white'); iconContainer.innerHTML = '<i class="fa-solid fa-check text-2xl text-black"></i>'; iconContainer.classList.replace('bg-white/5', 'bg-white'); iconContainer.classList.replace('text-white', 'text-black'); } else { display.innerText = t('touch_bin'); display.classList.replace('text-white', 'text-white/50'); iconContainer.innerHTML = '<i class="fa-solid fa-file-code text-2xl"></i>'; iconContainer.classList.replace('bg-white', 'bg-white/5'); iconContainer.classList.replace('text-black', 'text-white'); }
        }
        function previewLocal(input) { const img = document.getElementById('preview-img-local'), placeholder = document.getElementById('icon-file-placeholder'), name = document.getElementById('icon-file-name'); if (input.files && input.files[0]) { const reader = new FileReader(); reader.onload = function(e) { img.src = e.target.result; img.classList.remove('hidden'); placeholder.classList.add('hidden'); name.classList.add('hidden'); }; reader.readAsDataURL(input.files[0]); selectedIconType = 'local'; } }

        // --- SISTEMA DE CARGAS MODALES ---
        const modal = document.getElementById('custom-modal'), modalCard = document.getElementById('modal-card'), modalIcon = document.getElementById('modal-icon'), modalTitle = document.getElementById('modal-title'), modalText = document.getElementById('modal-text'), modalProgressContainer = document.getElementById('modal-progress-container'), modalProgressBar = document.getElementById('modal-progress-bar'), modalPercentage = document.getElementById('modal-percentage'), modalSpeed = document.getElementById('modal-speed'), modalETA = document.getElementById('modal-eta'), modalBytes = document.getElementById('modal-bytes'), modalCloseBtn = document.getElementById('modal-close-btn'), modalControls = document.getElementById('modal-controls');
        
        let wakeLock = null;
        async function requestWakeLock() { if (!document.getElementById('toggle_wakelock').checked) return; try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (err) {} }
        function releaseWakeLock() { if (wakeLock !== null) { wakeLock.release().then(() => wakeLock = null); } }
        let timeoutModalClose = null;

        function mostrarCarga(titulo, subtitulo, iconClass="fa-circle-notch fa-spin") {
            if(timeoutModalClose) clearTimeout(timeoutModalClose); 
            modalTitle.innerText = titulo; modalText.innerHTML = subtitulo;
            modalIcon.innerHTML = `<div class="absolute inset-0 rounded-full border border-white/30 animate-ping"></div><i class="fa-solid ${iconClass} text-3xl text-white relative z-10"></i>`;
            modalProgressContainer.classList.add('hidden'); modalControls.classList.add('hidden'); modalCloseBtn.classList.add('hidden');
            modal.classList.remove('hidden'); setTimeout(() => { modal.classList.remove('opacity-0'); modalCard.classList.remove('scale-95'); }, 10);
        }
        
        function closeCustomModal() { modal.classList.add('opacity-0'); modalCard.classList.add('scale-95'); timeoutModalClose = setTimeout(() => modal.classList.add('hidden'), 300); }
        
        function mostrarErrorFinal(titulo, msg) {
            if(timeoutModalClose) clearTimeout(timeoutModalClose); AudioEngine.playError();
            modal.classList.remove('hidden', 'opacity-0'); modalCard.classList.remove('scale-95');
            modalProgressContainer.classList.add('hidden'); modalControls.classList.add('hidden'); modalCloseBtn.classList.remove('hidden');
            modalTitle.innerText = titulo; modalText.innerHTML = msg;
            modalIcon.innerHTML = '<i class="fa-solid fa-triangle-exclamation text-4xl text-red-500"></i>'; modalIcon.className = "w-20 h-20 mx-auto rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(239,68,68,0.2)]";
            if (titulo === t('j_cancel')) { document.getElementById('file-upload').value = ''; updateFileName(document.getElementById('file-upload')); }
        }

        // ==========================================
        // TRANSFERENCIA FTP
        // ==========================================
        function togglePauseResume(forceErrorState = false, errorMsg = "") { 
            const btn = document.getElementById('modal-action-btn'); 
            if (forceErrorState) { isPaused = true; btn.className = "flex-1 btn-ps5-primary rounded-2xl py-3.5 font-bold text-[10px] tracking-widest"; btn.innerText = 'REINTENTAR'; document.getElementById('modal-text').innerHTML = `Error: ${errorMsg}`; return; } 
            isPaused = !isPaused; 
            if (isPaused) { btn.innerText = t('j_resume'); document.getElementById('modal-text').innerHTML = 'EN PAUSA'; modalSpeed.innerHTML = '<i class="fa-solid fa-bolt"></i> -- MB/s'; modalETA.innerHTML = '<i class="fa-solid fa-clock"></i> ETA: Pausado'; } 
            else { btn.innerText = t('modal_pause'); document.getElementById('modal-text').innerHTML = currentFileName; } 
        }
        function formatETA(seconds) { if (!isFinite(seconds) || seconds < 0) return "--:--"; let m = Math.floor(seconds / 60); let s = Math.floor(seconds % 60); return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`; }
        function cancelarEnvio() { if (uploadAbortController) uploadAbortController.abort(); document.getElementById('file-upload').value = ''; updateFileName(document.getElementById('file-upload')); }

        async function enviarArchivoChunks(event) {
            event.preventDefault(); const ip = document.getElementById('host-ip').value; const files = document.getElementById('file-upload').files; 
            if (!ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), 'fa-network-wired'); window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
            if (files.length === 0) { await ps5Alert(t('j_err_file'), t('j_err_file_m'), 'fa-file-circle-xmark'); return; }

            await requestWakeLock(); uploadAbortController = new AbortController(); const signal = uploadAbortController.signal; isTransferring = true;
            mostrarCarga(t('j_prep'), t('j_prep_m'), "fa-hard-drive fa-fade"); 
            let isCanceled = false, filesSuccess = 0; isPaused = false; document.getElementById('modal-action-btn').innerText = t('modal_pause');
            
            for (let f = 0; f < files.length; f++) {
                if (signal.aborted) { isCanceled = true; break; }
                const file = files[f]; currentFileName = file.name; let fileTotalGB = (file.size / (1024 * 1024 * 1024)); let remoteSize = 0; let isResume = false;
                
                let promptAction = '';
                try {
                    let fdCheck = new FormData(); fdCheck.append('action', 'check_file'); fdCheck.append('host_ip', ip); fdCheck.append('path', hiddenPathInput.value); fdCheck.append('file_name', file.name);
                    let resCheck = await fetch('api/upload.php', { method: 'POST', body: fdCheck, signal }); 
                    if(resCheck.ok) {
                        let dataCheck = await resCheck.json();
                        if (dataCheck.size > 0 && dataCheck.size < file.size) { promptAction = 'resume'; } else if (dataCheck.size >= file.size) { promptAction = 'exist'; }
                        if (promptAction !== '') {
                            closeCustomModal(); await new Promise(r => setTimeout(r, 350));
                            if (promptAction === 'resume') { let reanudar = await ps5Confirm(t('j_resume'), `${t('j_resume_m')} <br><b class="text-white mt-1 block">${file.name}</b>?`, 'fa-clock-rotate-left', 'bg-blue-500 text-white'); if (reanudar) { remoteSize = dataCheck.size; isResume = true; } } 
                            else { let sobreescribir = await ps5Confirm(t('j_exist'), `<b class="text-white">${file.name}</b><br>${t('j_exist_m')}`, 'fa-copy', 'bg-yellow-500 text-black'); if(!sobreescribir) { filesSuccess++; continue; } }
                        }
                    }
                } catch (e) {}
                
                if(timeoutModalClose) clearTimeout(timeoutModalClose);
                modal.classList.remove('hidden', 'opacity-0'); modalCard.classList.remove('scale-95');
                modalIcon.innerHTML = '<i class="fa-solid fa-cloud-arrow-up text-4xl text-white"></i>';
                modalProgressContainer.classList.remove('hidden'); modalControls.classList.remove('hidden'); 
                
                let uploadedBytes = remoteSize; modalTitle.innerText = `(${f + 1}/${files.length})`; modalText.innerHTML = file.name;
                
                while (uploadedBytes < file.size) {
                    if (signal.aborted) { isCanceled = true; break; }
                    while (isPaused) { if (signal.aborted) { isCanceled = true; break; } await new Promise(r => setTimeout(r, 500)); }
                    if (isCanceled) break;

                    let currentChunkSize = Math.min(CHUNK_SIZE, file.size - uploadedBytes); let chunk = file.slice(uploadedBytes, uploadedBytes + currentChunkSize); let isFirstRequest = (uploadedBytes === 0 && !isResume);
                    const formData = new FormData(); formData.append('action', 'upload_chunk'); formData.append('host_ip', ip); formData.append('selected_path', hiddenPathInput.value); formData.append('file_name', file.name); formData.append('is_first_chunk', isFirstRequest ? 'true' : 'false'); formData.append('archivo_subida', chunk);
                    let chunkStartTime = Date.now();

                    try {
                        let res = await new Promise((resolve, reject) => {
                            const xhr = new XMLHttpRequest(); xhr.open("POST", 'api/upload.php', true);
                            const abortHandler = () => { xhr.abort(); reject(new DOMException("Aborted", "AbortError")); };
                            if (signal) { if (signal.aborted) return abortHandler(); signal.addEventListener("abort", abortHandler); }
                            xhr.upload.onprogress = (e) => {
                                if (!e.lengthComputable || isPaused) return;
                                let actualLoaded = uploadedBytes + e.loaded; let pct = (actualLoaded / file.size) * 100;
                                modalProgressBar.style.width = pct + '%'; modalPercentage.innerText = pct.toFixed(0) + '%'; modalBytes.innerText = `${(actualLoaded / (1024 * 1024 * 1024)).toFixed(2)} / ${fileTotalGB.toFixed(2)} GB`;
                                let timeTaken = Math.max((Date.now() - chunkStartTime) / 1000, 0.001); 
                                if (timeTaken > 0.5 && e.loaded > 0) {
                                    let speedMBps = (e.loaded / timeTaken) / (1024 * 1024); modalSpeed.innerHTML = `<i class="fa-solid fa-bolt text-white/40"></i> ${speedMBps.toFixed(1)} MB/s`;
                                    let remainingBytes = file.size - actualLoaded; let remainingSecs = speedMBps > 0 ? (remainingBytes / (speedMBps * 1024 * 1024)) : 0; modalETA.innerHTML = `<i class="fa-solid fa-clock text-white/40"></i> ETA: ${formatETA(remainingSecs)}`;
                                }
                            };
                            xhr.onload = () => { if (signal) signal.removeEventListener("abort", abortHandler); if (xhr.status >= 200 && xhr.status < 300) { try { resolve(JSON.parse(xhr.responseText)); } catch(err) { reject(new Error("Invalid JSON")); } } else { reject(new Error(`Server error: ${xhr.status}`)); } };
                            xhr.onerror = () => { if (signal) signal.removeEventListener("abort", abortHandler); reject(new Error("Network error")); };
                            xhr.send(formData);
                        });
                        if (res.status !== 'success') throw new Error(res.message);
                        uploadedBytes += currentChunkSize; 
                    } catch (error) { if (error.name === 'AbortError') { isCanceled = true; break; } togglePauseResume(true, "Red falló. Toca REINTENTAR."); continue; } 
                }
                if (isCanceled) break; filesSuccess++;
            }
            
            releaseWakeLock(); isTransferring = false;
            if (isCanceled) { mostrarErrorFinal(t('j_cancel'), t('j_cancel_m')); } 
            else if (filesSuccess === files.length) {
                if (document.getElementById('toggle_autoinstall').checked) { let pkgFiles = Array.from(files).filter(f => f.name.toLowerCase().endsWith('.pkg')); pkgFiles.forEach(pkg => { fetch(`http://${ip}:12800/api/install`, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ "type": "direct", "packages": [(hiddenPathInput.value.endsWith('/') ? hiddenPathInput.value : hiddenPathInput.value + '/') + pkg.name] }) }).catch(e=>{}); }); }
                AudioEngine.playSuccess(); modalProgressContainer.classList.add('hidden'); modalControls.classList.add('hidden'); modalCloseBtn.classList.remove('hidden');
                modalTitle.innerText = t('j_comp'); modalText.innerHTML = t('j_comp_m'); 
                modalIcon.innerHTML = '<i class="fa-solid fa-check text-4xl text-white"></i>'; modalIcon.className = "w-20 h-20 mx-auto rounded-full bg-white/20 border border-white flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(255,255,255,0.4)]";
                document.getElementById('file-upload').value = ''; updateFileName(document.getElementById('file-upload'));
            }
        }

        async function enviarPayload(e) {
            e.preventDefault(); const ip = document.getElementById('host-ip').value; const port = document.getElementById('payload-port').value;
            if (!ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), 'fa-network-wired'); switchTab('tab-ftp', document.querySelectorAll('.dock-item')[0], 0); return; }
            const formData = new FormData(); formData.append('action', 'send_payload'); formData.append('host_ip', ip); formData.append('port', port);
            if (currentPayloadSource === 'gallery') { if (!selectedPayloadValue) { await ps5Alert(t('j_err_file'), t('j_err_file_m'), 'fa-microchip'); return; } formData.append('source_type', 'gallery'); formData.append('payload_path', selectedPayloadValue); } else { const fileInput = document.getElementById('payload-file'); if (!fileInput.files || fileInput.files.length === 0) { await ps5Alert(t('j_err_file'), t('j_err_file_m'), 'fa-file-code'); return; } formData.append('source_type', 'local'); formData.append('payload_file', fileInput.files[0]); }
            mostrarCarga(t('j_inj'), t('j_inj_m'), "fa-microchip fa-bounce"); 
            isTransferring = true;
            try {
                let res = await fetch('api/payload.php', { method: 'POST', body: formData }); let data = await res.json();
                if (data.status === 'success') { 
                    AudioEngine.playSuccess(); modalTitle.innerText = t('j_succ'); modalText.innerHTML = data.message; modalCloseBtn.classList.remove('hidden'); 
                    modalIcon.innerHTML = '<i class="fa-solid fa-check text-4xl text-white"></i>'; modalIcon.className = "w-20 h-20 mx-auto rounded-full bg-white/20 border border-white flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(255,255,255,0.4)]"; 
                    if(currentPayloadSource === 'local') { document.getElementById('payload-file').value = ''; updatePayloadName(document.getElementById('payload-file')); } 
                } else { mostrarErrorFinal(t('j_err'), data.message); }
            } catch (error) { mostrarErrorFinal(t('j_err'), t('j_err_net')); } finally { isTransferring = false; }
        }

        // ==========================================
        // FUNCIONES MODDING & BACKUPS
        // ==========================================
        function ejecutarFormIconos() { const form = document.getElementById('icon-form'); if (form.reportValidity()) { document.getElementById('icon-form-submit').click(); } }

        async function importarURL() {
            const urlInput = document.getElementById('import-url').value.trim();
            if (!urlInput) { await ps5Alert(t('j_err_file'), "Por favor, pega un enlace válido.", 'fa-link'); return; }
            mostrarCarga("IMPORTANDO", "Descargando imágenes a tu celular...", "fa-cloud-arrow-down fa-bounce");
            isTransferring = true; 
            const fd = new FormData(); fd.append('action', 'import_url'); fd.append('url', urlInput);
            try {
                let res = await fetch('api/gallery.php', { method: 'POST', body: fd }); let data = await res.json();
                if (data.status === 'success') {
                    AudioEngine.playSuccess(); closeCustomModal(); await ps5Alert("IMPORTACIÓN COMPLETA", data.message, 'fa-check', 'bg-blue-600 text-white');
                    document.getElementById('import-url').value = ''; await actualizarGaleria(); switchIconSource('gallery');
                } else { mostrarErrorFinal(t('j_err'), data.message); }
            } catch (e) { mostrarErrorFinal(t('j_err'), "Error de red al intentar descargar la imagen."); } finally { isTransferring = false; }
        }

        async function actualizarGaleria() { try { let res = await fetch('api/gallery.php?action=get_gallery'); let data = await res.json(); if (data.status === 'success') { ICONOS_LOCALES = data.data; cargarGaleria(ICONOS_LOCALES, 'gallery-container', 'iconos'); } } catch(e) {} }
        async function actualizarBackups() { try { let res = await fetch('api/gallery.php?action=get_backups'); let data = await res.json(); if (data.status === 'success') { BACKUPS_LOCALES = data.data; cargarGaleria(BACKUPS_LOCALES, 'backup-container', 'backup_icons'); } } catch(e) {} }

        // MODO "ESTE" (Individual)
        async function respaldarOriginal() {
            const ip = document.getElementById('host-ip').value; const cusa = document.getElementById('icon-cusa').value.trim().toUpperCase();
            if (!ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), 'fa-network-wired'); return; }
            if (!cusa) { await ps5Alert("FALTA TITLE ID", "Escribe el CUSA del juego para extraer la portada.", 'fa-gamepad'); return; }
            mostrarCarga("EXTRAYENDO", "Descargando portada desde la PS4...", "fa-download fa-bounce");
            isTransferring = true; // DETIENE EL ESCANER

            const fd = new FormData(); fd.append('action', 'backup_original'); fd.append('host_ip', ip); fd.append('cusa_id', cusa);
            try {
                let res = await fetch('api/modding.php', { method: 'POST', body: fd }); let data = await res.json();
                if (data.status === 'success') { AudioEngine.playSuccess(); closeCustomModal(); await ps5Alert("RESPALDO EXITOSO", data.message, 'fa-check', 'bg-blue-600 text-white'); switchIconSource('backup'); } 
                else { mostrarErrorFinal(t('j_err'), data.message); }
            } catch (e) { mostrarErrorFinal(t('j_err'), "Error de red al intentar descargar la portada."); } finally { isTransferring = false; }
        }

        // ===============================================
        // 🔥 EL SAQUEO TOTAL INTELIGENTE FRONTAL 🔥
        // ===============================================
        async function respaldarTodos() {
            const ip = document.getElementById('host-ip').value;
            if (!ip) { await ps5Alert("FALTA IP", "Asegúrate de estar conectado a la consola.", "fa-network-wired"); return; }
            
            mostrarCarga("ESCANEO TOTAL", "Leyendo biblioteca completa de la PS4...", "fa-radar fa-spin");
            isTransferring = true; // Detiene el escáner de red para no chocar
            
            try {
                const fd = new FormData(); fd.append('action', 'get_all_cusa'); fd.append('host_ip', ip);
                let res = await fetch('api/modding.php', { method: 'POST', body: fd });
                let data = await res.json();
                
                if (data.status === 'success' && data.juegos.length > 0) {
                    let juegos = data.juegos;
                    let exitos = 0;
                    
                    modalProgressContainer.classList.remove('hidden');
                    modalControls.classList.add('hidden');
                    
                    for(let i=0; i < juegos.length; i++) {
                        let cusa = juegos[i];
                        modalTitle.innerText = `SAQUEO (${i+1}/${juegos.length})`;
                        modalText.innerHTML = `Descargando portada de <b>${cusa}</b>...`;
                        let pct = ((i) / juegos.length) * 100;
                        modalProgressBar.style.width = pct + '%';
                        modalPercentage.innerText = pct.toFixed(0) + '%';
                        
                        const fdBak = new FormData(); fdBak.append('action', 'backup_original'); fdBak.append('host_ip', ip); fdBak.append('cusa_id', cusa);
                        try {
                            let r = await fetch('api/modding.php', { method: 'POST', body: fdBak });
                            let d = await r.json();
                            if (d.status === 'success') exitos++;
                            if (exitos % 2 === 0) actualizarBackups(); 
                        } catch(e) {}
                    }
                    
                    modalProgressBar.style.width = '100%'; modalPercentage.innerText = '100%';
                    AudioEngine.playSuccess(); closeCustomModal();
                    await ps5Alert("SAQUEO COMPLETO", `Se extrajeron <b>${exitos}</b> portadas de ${juegos.length} juegos detectados en tu consola.`, 'fa-check-double', 'bg-purple-600 text-white');
                    switchIconSource('backup');
                } else {
                    mostrarErrorFinal("SIN JUEGOS", "No se encontraron juegos instalados en las carpetas comunes.");
                }
            } catch(e) {
                mostrarErrorFinal("ERROR", "Falló la conexión de lectura con la PS4.");
            } finally {
                isTransferring = false;
            }
        }

        async function eliminarImagenGaleria(e, filename, tipoCarpeta) {
            e.stopPropagation(); 
            const seguro = await ps5Confirm("ELIMINAR IMAGEN", `¿Seguro que deseas eliminar <b>${filename}</b> de tu celular?`, 'fa-trash', 'bg-red-600 text-white border border-red-500');
            if (!seguro) return;
            mostrarCarga("ELIMINANDO", "Borrando archivo...", "fa-trash fa-bounce text-red-500");
            isTransferring = true; 
            const fd = new FormData(); fd.append('action', 'delete_image'); fd.append('filename', filename); fd.append('type', tipoCarpeta);
            try {
                let res = await fetch('api/gallery.php', { method: 'POST', body: fd }); let data = await res.json();
                if (data.status === 'success') { closeCustomModal(); if (tipoCarpeta === 'iconos') actualizarGaleria(); if (tipoCarpeta === 'backup_icons') actualizarBackups(); } 
                else { mostrarErrorFinal(t('j_err'), data.message); }
            } catch (err) { mostrarErrorFinal(t('j_err'), "Error de conexión al eliminar."); } finally { isTransferring = false; }
        }

        async function enviarIcono(e) {
            e.preventDefault(); const ip = document.getElementById('host-ip').value; const cusa = document.getElementById('icon-cusa').value.trim().toUpperCase();
            if (!ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), 'fa-network-wired'); window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
            if (!cusa) { await ps5Alert("FALTA TITLE ID", "Escribe el CUSA del juego (Ej: CUSA12345).", 'fa-gamepad'); return; }

            const formData = new FormData(); formData.append('action', 'upload_icon'); formData.append('host_ip', ip); formData.append('cusa_id', cusa);
            if (currentIconSource === 'gallery' || currentIconSource === 'backup') {
                if (!selectedIconValue) { await ps5Alert(t('j_err_file'), "Toca una imagen de la galería o backups para seleccionarla.", 'fa-images'); return; }
                formData.append('source_type', 'local_gallery'); formData.append('icon_path', selectedIconValue); 
            } else { 
                const fileInput = document.getElementById('icon-file');
                if (!fileInput.files || fileInput.files.length === 0) { await ps5Alert(t('j_err_file'), "Toca el cuadro para buscar una imagen en tu dispositivo.", 'fa-file-image'); return; }
                formData.append('source_type', 'local'); formData.append('local_icon', fileInput.files[0]);
            }

            mostrarCarga("MODDING", "Inyectando nueva portada...", "fa-wand-magic-sparkles fa-bounce"); isTransferring = true;
            try {
                let res = await fetch('api/modding.php', { method: 'POST', body: formData }); let data = await res.json();
                if (data.status === 'success') {
                    AudioEngine.playSuccess(); modalTitle.innerText = t('j_succ'); modalText.innerHTML = "Portada inyectada con éxito.<br><br><span class='text-[9px] text-white/50'>Reconstruye la base de datos de la PS4 o reiníciala para ver los cambios.</span>"; modalCloseBtn.classList.remove('hidden');
                    modalIcon.innerHTML = '<i class="fa-solid fa-palette text-4xl text-white"></i>'; modalIcon.className = "w-20 h-20 mx-auto rounded-full bg-white/20 border border-white flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(255,255,255,0.4)]";
                    if (currentIconSource === 'local') { document.getElementById('icon-file').value = ''; document.getElementById('preview-img-local').classList.add('hidden'); document.getElementById('icon-file-placeholder').classList.remove('hidden'); document.getElementById('icon-file-name').classList.remove('hidden'); }
                } else { mostrarErrorFinal(t('j_err'), data.message); }
            } catch (error) { mostrarErrorFinal(t('j_err'), "Error conectando con api/modding.php. Revisa la red."); } finally { isTransferring = false; }
        }

        // ==========================================
        // EXPLORADOR
        // ==========================================
        let currentExplorerPath = '', optionsPath = '', optionsName = '', optionsIsDir = false, clipboardPath = '', clipboardName = ''; 
        let currentExplorerItems = []; let isSelectMode = false; let selectedItems = [];

        function renderShortcuts() {
            let shortcuts = JSON.parse(localStorage.getItem('ps4_explorer_shortcuts')) || []; const container = document.getElementById('explorer-shortcuts');
            if(shortcuts.length === 0) { container.classList.add('hidden'); return; } container.classList.remove('hidden'); let html = '<i class="fa-solid fa-star text-yellow-500/50 text-[10px] mr-1 shrink-0"></i>';
            shortcuts.forEach(path => { let name = path === '/' ? 'RAÍZ' : path.split('/').filter(Boolean).pop(); html += `<div class="flex items-center gap-1 bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-full text-[10px] font-bold text-white cursor-pointer whitespace-nowrap group"><span onclick="loadExplorerPath('${path}')" class="truncate max-w-[80px]">${name}</span><div onclick="removeShortcut('${path}', event)" class="w-4 h-4 rounded-full bg-black/40 hover:bg-red-500/80 flex items-center justify-center ml-1 transition-colors"><i class="fa-solid fa-xmark text-[10px] text-white/50 group-hover:text-white"></i></div></div>`; });
            container.innerHTML = html;
        }
        function addCurrentPathToShortcuts() { if(!currentExplorerPath) return; let shortcuts = JSON.parse(localStorage.getItem('ps4_explorer_shortcuts')) || []; if(!shortcuts.includes(currentExplorerPath)) { shortcuts.push(currentExplorerPath); localStorage.setItem('ps4_explorer_shortcuts', JSON.stringify(shortcuts)); renderShortcuts(); } }
        async function removeShortcut(path, e) { e.stopPropagation(); const confirmado = await ps5Confirm(t('j_fav_rem'), `${t('j_fav_rem_m')} <br><b class="text-white font-mono mt-2 block">${path}</b>?`, 'fa-star-half-stroke', 'bg-yellow-500 text-black'); if(!confirmado) return; let shortcuts = JSON.parse(localStorage.getItem('ps4_explorer_shortcuts')) || []; shortcuts = shortcuts.filter(p => p !== path); localStorage.setItem('ps4_explorer_shortcuts', JSON.stringify(shortcuts)); renderShortcuts(); }

        function toggleSelectMode() {
            isSelectMode = !isSelectMode; selectedItems = []; const btn = document.getElementById('btn-select-mode'); const panel = document.getElementById('multi-action-panel');
            if (isSelectMode) { btn.classList.add('bg-blue-600', 'border-blue-500'); btn.classList.replace('hover:bg-blue-500/20', 'hover:bg-blue-500'); panel.classList.remove('hidden'); } 
            else { btn.classList.remove('bg-blue-600', 'border-blue-500'); btn.classList.replace('hover:bg-blue-500', 'hover:bg-blue-500/20'); panel.classList.add('hidden'); }
            if(currentExplorerItems) renderExplorer(currentExplorerItems, currentExplorerPath);
        }
        function toggleSelectItem(path, isDir) { let idx = selectedItems.findIndex(i => i.path === path); if(idx > -1) { selectedItems.splice(idx, 1); } else { selectedItems.push({path, isDir}); } document.getElementById('multi-select-count').innerText = `${selectedItems.length} ${t('j_sel')}`; renderExplorer(currentExplorerItems, currentExplorerPath); }

        async function deleteSelectedItems() {
            if (selectedItems.length === 0) return;
            const seguro1 = await ps5Confirm(t('j_del_sel'), `${t('j_del_m1')} <b>${selectedItems.length} ${t('j_elem')}</b>?`, 'fa-trash', 'bg-red-500 text-white border border-red-400'); if (!seguro1) return;
            const seguro2 = await ps5Confirm(t('j_warn'), t('j_warn_m'), 'fa-triangle-exclamation text-red-500', 'bg-red-600 text-white shadow-[0_0_15px_rgba(220,38,38,0.5)] border border-red-400'); if (!seguro2) return;
            
            mostrarCarga(t('j_del_sel'), `${t('j_del_prog')} ${selectedItems.length} ${t('j_elem')}...`, "fa-trash fa-bounce text-red-500");
            let successCount = 0; const ip = document.getElementById('host-ip').value;
            isTransferring = true;
            for (let i = 0; i < selectedItems.length; i++) { let item = selectedItems[i]; const fd = new FormData(); fd.append('action', 'delete_item'); fd.append('host_ip', ip); fd.append('path', item.path); fd.append('is_dir', item.isDir); try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') successCount++; } catch(e) {} }
            isTransferring = false;
            closeCustomModal(); toggleSelectMode(); loadExplorerPath(currentExplorerPath);
            if (successCount < selectedItems.length) { setTimeout(async () => { await ps5Alert(t('j_del_part'), t('j_del_part_m'), 'fa-circle-exclamation text-yellow-500'); }, 400); } else if (successCount > 0) { AudioEngine.playSuccess(); }
        }

        async function loadExplorerPath(path) {
            const ip = document.getElementById('host-ip').value; const listContainer = document.getElementById('explorer-list'); const pathText = document.getElementById('explorer-path-text');
            if(!ip) { listContainer.innerHTML = `<div class="text-center text-red-400 text-xs py-10">${t('config_ip')}</div>`; return; }
            if(isSelectMode && path !== currentExplorerPath) toggleSelectMode();
            
            pathText.innerText = path.length > 25 ? '...' + path.slice(-25) : path; currentExplorerPath = path;
            listContainer.innerHTML = `<div class="text-center text-white/50 text-xs py-10"><i class="fa-solid fa-circle-notch fa-spin text-3xl mb-3 block"></i>${t('searching')}</div>`;
            const fd = new FormData(); fd.append('action', 'list_dir'); fd.append('host_ip', ip); fd.append('path', path);
            isTransferring = true;
            try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if (data.status === 'success') renderExplorer(data.data, path); else listContainer.innerHTML = `<div class="text-center text-red-400 text-xs py-10">${data.message}</div>`; } catch(e) { listContainer.innerHTML = `<div class="text-center text-red-400 text-xs py-10">${t('j_err_net')}</div>`; } finally { isTransferring = false; }
        }

        function renderExplorer(items, currentPath) {
            currentExplorerItems = items; const listContainer = document.getElementById('explorer-list'); listContainer.innerHTML = '';
            if (currentPath !== '/') { let parentPath = currentPath.substring(0, currentPath.lastIndexOf('/', currentPath.length - 2)) + '/'; if(parentPath === '') parentPath = '/'; listContainer.innerHTML += `<div onclick="loadExplorerPath('${parentPath}')" class="flex items-center gap-4 p-3 rounded-xl hover:bg-white/10 cursor-pointer transition-colors"><i class="fa-solid fa-level-up-alt text-xl text-white/50"></i><span class="text-sm font-medium text-white/80">Volver</span></div>`; }
            if (items.length === 0) { listContainer.innerHTML += `<div class="text-center text-white/30 text-xs py-10">${t('j_empty')}</div>`; return; }
            items.forEach(item => {
                let isDir = item.is_dir; let icon = isDir ? 'fa-folder text-yellow-500/80' : 'fa-file-lines text-white/40';
                let nextPath = currentPath.endsWith('/') ? currentPath + item.name : currentPath + '/' + item.name; if(isDir) nextPath += '/';
                let isChecked = selectedItems.some(i => i.path === nextPath); let bgClass = isChecked ? 'bg-blue-500/20 border-blue-500/50' : 'hover:bg-white/10 border-transparent'; let checkIcon = isChecked ? 'opacity-100' : 'opacity-0';
                let clickAction = isSelectMode ? `onclick="toggleSelectItem('${nextPath}', ${isDir})"` : (isDir ? `onclick="loadExplorerPath('${nextPath}')"` : '');
                let checkboxHTML = isSelectMode ? `<div class="w-5 h-5 rounded border border-white/30 flex items-center justify-center shrink-0 mr-1 ${isChecked ? 'bg-blue-500 border-blue-500' : ''}"><i class="fa-solid fa-check text-[10px] text-white ${checkIcon}"></i></div>` : '';
                let sizeStr = isDir ? '' : `<span class="text-[9px] text-white/30">${(item.size / (1024*1024)).toFixed(2)} MB</span>`;
                listContainer.innerHTML += `<div class="flex items-center justify-between p-3 rounded-xl transition-colors border ${bgClass}"><div class="flex items-center gap-3 flex-1 cursor-pointer overflow-hidden" ${clickAction}>${checkboxHTML}<i class="fa-solid ${icon} text-2xl w-6 text-center shrink-0"></i><div class="flex flex-col overflow-hidden"><span class="text-sm font-medium text-white tracking-wide truncate pr-2">${item.name}</span>${sizeStr}</div></div>${!isSelectMode ? `<button onclick="openItemOptions('${nextPath}', '${item.name}', ${isDir})" class="text-white/50 hover:text-white p-2 px-3 shrink-0"><i class="fa-solid fa-ellipsis-vertical"></i></button>` : ''}</div>`;
            });
        }

        function openItemOptions(path, name, isDir) { optionsPath = path; optionsName = name; optionsIsDir = isDir; document.getElementById('sheet-title').innerText = name; document.getElementById('overlay-sheet').classList.add('open'); document.getElementById('bottom-sheet').classList.add('open'); }
        function closeItemOptions() { document.getElementById('overlay-sheet').classList.remove('open'); document.getElementById('bottom-sheet').classList.remove('open'); }
        async function renameCurrentItem() { closeItemOptions(); let newName = await ps5Prompt(t('j_ren'), `${t('j_ren_m')}<br><b class="text-white font-mono block mt-2">${optionsName}</b>`, optionsName); if(!newName || newName === optionsName) return; let pathParts = optionsPath.split('/').filter(Boolean); pathParts.pop(); let basePath = '/' + pathParts.join('/') + (pathParts.length > 0 ? '/' : ''); let newPath = basePath + newName + (optionsIsDir ? '/' : ''); const fd = new FormData(); fd.append('action', 'rename'); fd.append('host_ip', document.getElementById('host-ip').value); fd.append('old_path', optionsPath); fd.append('new_path', newPath); isTransferring = true; try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { AudioEngine.playSuccess(); loadExplorerPath(currentExplorerPath); } else await ps5Alert(t('j_err'), data.message, 'fa-circle-xmark text-red-500'); } catch(e) { await ps5Alert(t('j_err'), t('j_err_net'), 'fa-wifi'); } finally { isTransferring = false; } }
        function cutCurrentItem() { closeItemOptions(); clipboardPath = optionsPath; clipboardName = optionsName; document.getElementById('clipboard-panel').classList.remove('hidden'); document.getElementById('clipboard-text').innerText = clipboardName; }
        function cancelPaste() { clipboardPath = ''; clipboardName = ''; document.getElementById('clipboard-panel').classList.add('hidden'); }
        async function executePaste() { if(!clipboardPath) return; let newPath = currentExplorerPath.endsWith('/') ? currentExplorerPath + clipboardName : currentExplorerPath + '/' + clipboardName; const fd = new FormData(); fd.append('action', 'rename'); fd.append('host_ip', document.getElementById('host-ip').value); fd.append('old_path', clipboardPath); fd.append('new_path', newPath); isTransferring = true; try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { AudioEngine.playSuccess(); cancelPaste(); loadExplorerPath(currentExplorerPath); } else await ps5Alert(t('j_err_paste'), data.message, 'fa-paste text-red-500'); } catch(e) { await ps5Alert(t('j_err'), t('j_err_net'), 'fa-wifi'); } finally { isTransferring = false; } }
        async function deleteCurrentItem() { closeItemOptions(); const seguro1 = await ps5Confirm(t('j_del1'), `${t('j_del1')} <b class="text-white">${optionsName}</b>?`, 'fa-trash', 'bg-red-500 text-white border border-red-400'); if(!seguro1) return; const seguro2 = await ps5Confirm(t('j_warn'), t('j_warn_m'), 'fa-triangle-exclamation text-red-500', 'bg-red-600 text-white shadow-[0_0_15px_rgba(220,38,38,0.5)] border border-red-400'); if(!seguro2) return; const fd = new FormData(); fd.append('action', 'delete_item'); fd.append('host_ip', document.getElementById('host-ip').value); fd.append('path', optionsPath); fd.append('is_dir', optionsIsDir); isTransferring = true; try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { AudioEngine.playSuccess(); loadExplorerPath(currentExplorerPath); } else await ps5Alert(t('j_err'), data.message, 'fa-circle-xmark text-red-500'); } catch(e) { await ps5Alert(t('j_err'), t('j_err_net'), 'fa-wifi'); } finally { isTransferring = false; } }
        async function promptCreateFolder() { let name = await ps5Prompt(t('j_new_fold'), t('j_new_fold_m')); if(!name) return; let newPath = currentExplorerPath.endsWith('/') ? currentExplorerPath + name : currentExplorerPath + '/' + name; const fd = new FormData(); fd.append('action', 'mkdir'); fd.append('host_ip', document.getElementById('host-ip').value); fd.append('path', newPath); isTransferring = true; try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { AudioEngine.playSuccess(); loadExplorerPath(currentExplorerPath); } else await ps5Alert(t('j_err'), data.message, 'fa-folder-xmark text-red-500'); } catch(e) { await ps5Alert(t('j_err'), t('j_err_net'), 'fa-wifi'); } finally { isTransferring = false; } }

        // ==========================================
        // SISTEMA DE PERFIL DINÁMICO PS4
        // ==========================================
        let cachedAvatar = null;
        let customUserName = localStorage.getItem('ps4_custom_username') || 'USUARIO PS4';

        async function cambiarNombreUsuario() {
            if(!wasConnected) { await ps5Alert("DESCONECTADO", "Debes estar conectado a tu consola para cambiar el nombre de usuario.", "fa-plug-circle-xmark"); return; }
            let nuevoNombre = await ps5Prompt("NOMBRE DE USUARIO", "Introduce tu nombre de PS4:", customUserName);
            if(nuevoNombre && nuevoNombre.trim() !== "") {
                customUserName = nuevoNombre.trim().toUpperCase();
                localStorage.setItem('ps4_custom_username', customUserName);
                document.getElementById('profile-name').innerText = customUserName;
            }
        }

        async function fetchPS4Profile(ip) {
            if (cachedAvatar) { aplicarAvatar(cachedAvatar, customUserName); return; }
            isTransferring = true; 
            const fd = new FormData(); fd.append('action', 'get_ps4_profile'); fd.append('host_ip', ip);
            try {
                let res = await fetch('api/modding.php', { method: 'POST', body: fd });
                let data = await res.json();
                if (data.status === 'success' && data.avatar) {
                    cachedAvatar = data.avatar;
                    aplicarAvatar(cachedAvatar, customUserName);
                } else { aplicarAvatar(null, customUserName); }
            } catch(e) { aplicarAvatar(null, customUserName); } finally { isTransferring = false; }
        }

        function aplicarAvatar(base64Img, nombre) {
            const av = document.getElementById('profile-avatar'), ini = document.getElementById('profile-initial'), nm = document.getElementById('profile-name');
            if (base64Img) { 
                av.style.backgroundImage = `url('${base64Img}')`; 
                av.style.backgroundColor = 'transparent'; 
                av.style.borderColor = 'rgba(255,255,255,0.2)'; 
                av.classList.remove('rounded-full');
                av.classList.add('rounded-xl');
                ini.classList.add('hidden'); 
            } 
            else { 
                av.style.backgroundImage = ''; 
                av.style.backgroundColor = '#2563EB'; 
                av.style.borderColor = '#1D4ED8'; 
                av.classList.remove('rounded-xl');
                av.classList.add('rounded-full');
                ini.innerText = nombre.charAt(0); 
                ini.classList.remove('hidden'); 
            }
            nm.innerText = nombre; nm.classList.replace('text-[#A1A1AA]', 'text-white');
        }

        function resetAvatarLocal() {
            const av = document.getElementById('profile-avatar'), ini = document.getElementById('profile-initial'), nm = document.getElementById('profile-name');
            av.style.backgroundImage = ''; 
            av.style.backgroundColor = '#549E43'; 
            av.style.borderColor = '#386C2B'; 
            av.classList.remove('rounded-xl');
            av.classList.add('rounded-full');
            ini.innerText = 'S'; 
            ini.classList.remove('hidden');
            nm.innerText = 'BY SEBAS'; nm.classList.replace('text-white', 'text-[#A1A1AA]');
        }

        // ==========================================
        // SCANNER RED E INICIALIZACIÓN
        // ==========================================
        const SUBRED_PHP = "<?php echo $subred_actual; ?>";
        document.addEventListener('DOMContentLoaded', () => {
            cargarGaleria(ICONOS_LOCALES, 'gallery-container', 'iconos');
            cargarGaleria(BACKUPS_LOCALES, 'backup-container', 'backup_icons');
            cargarGaleriaPayloads(); renderShortcuts(); 
            
            const savedIp = localStorage.getItem('ps4_ip_guardada');
            if(savedIp) { document.getElementById('host-ip').value = savedIp; setPS4State(true); startConnectionMonitor(savedIp); }
            
            const savedFolders = JSON.parse(localStorage.getItem('ps4_custom_folders')) || [];
            savedFolders.forEach(folder => crearBotonCarpeta(folder, false));
            
            const btnFtp = document.getElementById('floating-btn-ftp'); if(btnFtp) btnFtp.classList.remove('floating-hidden');
            if(localStorage.getItem('ps4_custom_username')) { customUserName = localStorage.getItem('ps4_custom_username'); }
        });

        let isScanning = false, abortController = null, radarAnimInterval = null, connectionMonitorInterval = null; 
        let wasConnected = false; let failedPings = 0; 
        
        function setPS4State(isConnected) {
            if (wasConnected === true && isConnected === false) { AudioEngine.playDisconnect(); resetAvatarLocal(); }
            wasConnected = isConnected;
            const badgeOn = document.getElementById('badge-detectada'), badgeOff = document.getElementById('badge-desconectada');
            
            if(isConnected) { 
                badgeOn.classList.remove('hidden'); badgeOn.classList.add('flex'); badgeOff.classList.add('hidden'); badgeOff.classList.remove('flex'); 
                const ip = document.getElementById('host-ip').value;
                if(ip) fetchPS4Profile(ip);
            } else { 
                badgeOff.classList.remove('hidden'); badgeOff.classList.add('flex'); badgeOn.classList.add('hidden'); badgeOn.classList.remove('flex'); 
                resetAvatarLocal();
            }
        }
        
        function startConnectionMonitor(ip) { 
            if(connectionMonitorInterval) clearInterval(connectionMonitorInterval); failedPings = 0; setPS4State(true); 
            connectionMonitorInterval = setInterval(async () => { 
                if (isTransferring) return; 
                try { 
                    const checkController = new AbortController(); const timeoutId = setTimeout(() => checkController.abort(), 6000); 
                    let res = await fetch(`api/scanner.php?ip=${ip}`, { signal: checkController.signal, cache: 'no-store' }); clearTimeout(timeoutId);
                    let data = await res.json(); if (data.status === 'success') { failedPings = 0; setPS4State(true); } else { failedPings++; if (failedPings >= 2) setPS4State(false); }
                } catch(e) { failedPings++; if (failedPings >= 2) setPS4State(false); } 
            }, 12000); 
        }
        
        window.addEventListener('online', () => { const ip = document.getElementById('host-ip').value; if(ip) startConnectionMonitor(ip); });
        function clearIP() { if(isScanning) toggleRealScan(); document.getElementById('host-ip').value = ''; localStorage.removeItem('ps4_ip_guardada'); setPS4State(false); if(connectionMonitorInterval) clearInterval(connectionMonitorInterval); }
        function detenerUI() { isScanning = false; document.getElementById('host-ip').disabled = false; document.getElementById('global-status').classList.add('hidden'); clearInterval(radarAnimInterval); const btnScan = document.getElementById('btn-scan'); btnScan.innerHTML = '<i class="fa-solid fa-satellite-dish"></i>'; btnScan.className = 'w-12 h-12 rounded-xl bg-blue-600 hover:bg-blue-500 transition-all flex items-center justify-center text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] active:scale-95'; }
        
        async function toggleRealScan() {
            const globalStatus = document.getElementById('global-status'), scanText = document.getElementById('scan-text');
            if (isScanning) { if (abortController) abortController.abort(); detenerUI(); return; }
            isScanning = true; document.getElementById('host-ip').value = ''; document.getElementById('host-ip').disabled = true; globalStatus.classList.remove('hidden'); const btnScan = document.getElementById('btn-scan'); btnScan.className = 'w-12 h-12 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-[0_0_15px_rgba(239,68,68,0.4)] animate-pulse'; btnScan.innerHTML = '<i class="fa-solid fa-stop"></i>';
            radarAnimInterval = setInterval(() => { scanText.innerText = `${t('searching').replace('...', '')}: 192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 254) + 1}`; }, 60);
            abortController = new AbortController(); const signal = abortController.signal;
            try {
                let ipsToScan = ["192.168.0.22"]; for (let i = 2; i < 255; i++) { let ip = SUBRED_PHP + i; if(!ipsToScan.includes(ip)) ipsToScan.push(ip); }
                const BATCH_SIZE = 8; let foundIp = null;
                for (let i = 0; i < ipsToScan.length; i += BATCH_SIZE) {
                    if (signal.aborted) break; const batch = ipsToScan.slice(i, i + BATCH_SIZE);
                    const promises = batch.map(ip => fetch(`api/scanner.php?ip=${ip}`, { signal }).then(res => res.json()).then(data => { if (data.status === 'success') throw data; return null; }).catch(err => { if (err.status === 'success') return err.ip; if (err.name === 'AbortError') throw err; return null; }));
                    try { const results = await Promise.all(promises); const winner = results.find(res => res !== null); if (winner) { foundIp = winner; break; } } catch(e) { if (e.name === 'AbortError') break; }
                }
                if (foundIp) { detenerUI(); document.getElementById('host-ip').value = foundIp; localStorage.setItem('ps4_ip_guardada', foundIp); setPS4State(true); startConnectionMonitor(foundIp); AudioEngine.playSuccess(); } 
                else if (!signal.aborted) { detenerUI(); await ps5Alert(t('j_scan_fail'), t('j_scan_fail_m'), 'fa-satellite-dish'); }
            } catch (e) { detenerUI(); }
        }
        function connectManualIP() { const ip = document.getElementById('host-ip').value.trim(); if(ip) { localStorage.setItem('ps4_ip_guardada', ip); setPS4State(true); startConnectionMonitor(ip); } }

    </script>
</body>
</html>
